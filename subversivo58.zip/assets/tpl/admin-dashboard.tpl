<!-- ADMIN DASHBOARD -->
<section id="admin-dashboard" class="admin-dashboard-shell w-100">

    <!-- MOBILE HEADER -->
    <header class="admin-mobile-bar d-flex d-md-none align-items-center justify-content-between px-3 py-2 bg-white border-bottom">
        <button
            type="button"
            id="admin-sidebar-toggle"
            class="i18n btn btn-sm btn-outline-secondary rounded-0 cp d-inline-flex align-items-center"
            aria-controls="admin-sidebar"
            aria-expanded="false"
            data-i18n-title="admin_dashboard.menu">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                <line x1="3" y1="6" x2="21" y2="6"></line>
                <line x1="3" y1="12" x2="21" y2="12"></line>
                <line x1="3" y1="18" x2="21" y2="18"></line>
            </svg>
            <span class="i18n ml-2" data-i18n-html="admin_dashboard.menu"></span>
        </button>

        <span class="i18n font-weight-bold text-truncate mx-2" data-i18n-html="admin_dashboard.title"></span>

        <button
            type="button"
            id="admin-mobile-new-post"
            class="i18n btn btn-sm btn-info rounded-0 cp"
            data-i18n-title="admin_dashboard.new_post">+</button>
    </header>

    <div id="admin-sidebar-backdrop" class="admin-sidebar-backdrop d-md-none" hidden></div>

    <div class="admin-layout d-flex w-100">

        <!-- SIDEBAR UNIFICADA -->
        <aside id="admin-sidebar" class="admin-sidebar border-right d-flex flex-column" aria-label="Admin Navigation">

            <div class="admin-sidebar-head d-flex align-items-center justify-content-between px-3 py-3 border-bottom">
                <div class="min-w-0">
                    <div class="i18n font-weight-bold text-truncate" data-i18n-html="admin_dashboard.title"></div>
                    <small class="i18n text-muted d-block text-truncate" data-i18n-html="admin_dashboard.description"></small>
                </div>
                <button
                    type="button"
                    id="admin-sidebar-close"
                    class="i18n btn btn-sm btn-outline-secondary rounded-0 d-md-none ml-2 cp"
                    data-i18n-title="admin_dashboard.close_menu">&times;</button>
            </div>

            <nav class="admin-sidebar-nav p-2 flex-grow-1" role="tablist">

                <button
                    type="button"
                    data-admin-nav="posts"
                    class="admin-nav-btn active cp"
                    role="tab"
                    aria-selected="true">
                    <svg class="admin-nav-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="8" y1="13" x2="16" y2="13"></line>
                        <line x1="8" y1="17" x2="16" y2="17"></line>
                    </svg>
                    <span class="i18n admin-nav-label" data-i18n-html="admin_dashboard.posts"></span>
                    <span id="admin-posts-badge" class="badge badge-secondary ml-auto">0</span>
                </button>

                <button
                    type="button"
                    data-admin-nav="footoodles"
                    class="admin-nav-btn cp"
                    role="tab"
                    aria-selected="false">
                    <svg class="admin-nav-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                        <circle cx="8.5" cy="8.5" r="1.5"></circle>
                        <polyline points="21 15 16 10 5 21"></polyline>
                    </svg>
                    <span class="i18n admin-nav-label" data-i18n-html="admin_dashboard.footoodles.tab"></span>
                    <span id="admin-footoodles-badge" class="badge badge-secondary ml-auto">0</span>
                </button>

                <button
                    type="button"
                    data-admin-nav="session"
                    class="admin-nav-btn cp"
                    role="tab"
                    aria-selected="false">
                    <svg class="admin-nav-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                    </svg>
                    <span class="i18n admin-nav-label" data-i18n-html="admin_dashboard.nav.session"></span>
                    <span id="admin-session-nav-dot" class="admin-status-dot ml-auto" aria-hidden="true"></span>
                </button>

                <!-- CREDENCIAIS -->
                <button
                    type="button"
                    data-admin-nav="credentials"
                    class="admin-nav-btn cp"
                    role="tab"
                    aria-selected="false">
                    <svg class="admin-nav-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                        <circle cx="8" cy="15" r="5"></circle>
                        <path d="m10.5 11.5 9-9"></path>
                        <path d="M16 5l3 3"></path>
                        <path d="M13 8l3 3"></path>
                    </svg>
                    <span class="admin-nav-label">Credenciais</span>
                </button>

                <!-- REGISTROS -->
                <button
                    type="button"
                    data-admin-nav="records"
                    class="admin-nav-btn cp"
                    role="tab"
                    aria-selected="false">
                    <svg class="admin-nav-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                        <ellipse cx="12" cy="5" rx="9" ry="3"></ellipse>
                        <path d="M3 5v14c0 1.66 4.03 3 9 3s9-1.34 9-3V5"></path>
                        <path d="M3 12c0 1.66 4.03 3 9 3s9-1.34 9-3"></path>
                    </svg>
                    <span class="admin-nav-label">Registros</span>
                </button>

                <!-- DEVTOOLS -->
                <button
                    type="button"
                    data-admin-nav="devtools"
                    class="admin-nav-btn cp"
                    role="tab"
                    aria-selected="false">
                    <svg class="admin-nav-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                        <path d="M12 8V4"></path>
                        <path d="M8 4h8"></path>
                        <rect x="4" y="8" width="16" height="12" rx="2"></rect>
                        <path d="M9 13h.01"></path>
                        <path d="M15 13h.01"></path>
                        <path d="M9 17h6"></path>
                    </svg>
                    <span class="i18n admin-nav-label" data-i18n-html="admin_dashboard.devtools.title">DevTools</span>
                </button>

            </nav>

        </aside>

        <!-- ÁREA PRINCIPAL -->
        <main id="admin-dashboard-content" class="admin-main flex-grow-1 p-3 p-lg-4">

            <!-- VIEW 1: POSTAGENS -->
            <section id="admin-view-posts" class="admin-view">
                <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between mb-3 pb-3 border-bottom">
                    <div class="mb-2 mb-md-0">
                        <h1 class="i18n h4 mb-1" data-i18n-html="admin_dashboard.posts"></h1>
                        <p class="i18n text-muted small mb-0" data-i18n-html="admin_dashboard.posts_view.subtitle"></p>
                    </div>
                    <div class="d-flex flex-wrap align-items-center">
                        <input
                            type="search"
                            id="admin-posts-search"
                            class="i18n form-control form-control-sm rounded-0 mr-2 mb-2 mb-sm-0 admin-search-input"
                            data-i18n-place="admin_dashboard.posts_view.search_placeholder"
                            autocomplete="off">
                        <button
                            type="button"
                            id="admin-new-post"
                            class="i18n btn btn-info btn-sm rounded-0 px-3 cp"
                            data-i18n-html="admin_dashboard.new_post"></button>
                    </div>
                </div>

                <div id="admin-posts-empty" class="p-4 text-center border bg-white text-muted small" hidden>
                    <span class="i18n" data-i18n-html="admin_dashboard.posts_view.empty"></span>
                </div>

                <div id="admin-posts-list" class="admin-posts-grid"></div>
            </section>

            <!-- VIEW 2: EDITOR WYSIWYG -->
            <section id="admin-view-editor" class="admin-view" hidden>
                <div class="d-flex flex-wrap align-items-center justify-content-between mb-3 pb-2 border-bottom">
                    <div class="d-flex align-items-center">
                        <button
                            type="button"
                            id="admin-back-to-posts"
                            class="i18n btn btn-outline-secondary btn-sm rounded-0 mr-3 cp"
                            data-i18n-html="admin_dashboard.posts_view.back"></button>
                        <h2 id="admin-editor-heading" class="i18n h5 mb-0" data-i18n-html="admin_dashboard.new_post"></h2>
                    </div>
                </div>

                <div id="admin-post-editor" class="bg-white border p-3 p-lg-4"></div>
            </section>

            <!-- VIEW 3: FOOTOODLES -->
            <section id="admin-view-footoodles" class="admin-view" hidden>
                <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between mb-3 pb-3 border-bottom">
                    <div class="mb-2 mb-md-0">
                        <h2 class="i18n h4 mb-1" data-i18n-html="admin_dashboard.footoodles.title"></h2>
                        <p class="i18n text-muted small mb-0" data-i18n-html="admin_dashboard.footoodles.subtitle"></p>
                    </div>
                    <button
                        type="button"
                        data-footoodles-new
                        class="i18n btn btn-info btn-sm rounded-0 px-3 cp"
                        data-i18n-html="admin_dashboard.footoodles.new"></button>
                </div>

                <div id="admin-footoodles-editor-panel" class="mb-4" hidden></div>

                <div id="admin-footoodles-empty" class="p-4 text-center border bg-white text-muted small" hidden>
                    <span class="i18n" data-i18n-html="admin_dashboard.footoodles.empty"></span>
                </div>

                <div id="admin-footoodles-list" class="row"></div>
            </section>

            <!-- VIEW 4: SESSÃO GITHUB -->
            <section id="admin-view-session" class="admin-view" hidden>
                <div class="mb-3 pb-3 border-bottom">
                    <h2 class="i18n h4 mb-1" data-i18n-html="admin_dashboard.session.title"></h2>
                    <p class="i18n text-muted small mb-0" data-i18n-html="admin_dashboard.session.subtitle"></p>
                </div>

                <div class="row">
                    <div class="col-12 col-lg-6 mb-4">
                        <div class="card rounded-0 h-100 border">
                            <div class="card-body">
                                <div class="d-flex align-items-center mb-3">
                                    <picture class="mr-3 flex-shrink-0">
                                        <img
                                            id="admin-session-avatar"
                                            src="/assets/media/image/1x1.gif"
                                            data-src=""
                                            data-lazy-target
                                            alt=""
                                            class="rounded-circle border"
                                            width="64"
                                            height="64">
                                    </picture>
                                    <div class="min-w-0">
                                        <h3 id="admin-session-name" class="h5 mb-1 text-truncate"></h3>
                                        <p id="admin-session-login" class="small text-muted mb-1 text-truncate"></p>
                                        <span id="admin-session-status-badge" class="badge badge-secondary"></span>
                                    </div>
                                </div>

                                <dl class="row small mb-3">
                                    <dt class="i18n col-sm-5 text-muted" data-i18n-html="github_auth.identity.id_label"></dt>
                                    <dd id="admin-session-id" class="col-sm-7 mb-1 text-monospace"></dd>

                                    <dt class="i18n col-sm-5 text-muted" data-i18n-html="github_auth.identity.profile_label"></dt>
                                    <dd class="col-sm-7 mb-1 text-truncate">
                                        <a id="admin-session-profile" href="" target="_blank" rel="noopener noreferrer"></a>
                                    </dd>

                                    <dt class="i18n col-sm-5 text-muted" data-i18n-html="github_auth.identity.email_label"></dt>
                                    <dd id="admin-session-email" class="col-sm-7 mb-1 text-truncate"></dd>

                                    <dt class="i18n col-sm-5 text-muted" data-i18n-html="admin_dashboard.session.scope_label"></dt>
                                    <dd id="admin-session-scope" class="col-sm-7 mb-1 text-monospace"></dd>

                                    <dt class="i18n col-sm-5 text-muted" data-i18n-html="admin_dashboard.session.obtained_label"></dt>
                                    <dd id="admin-session-obtained" class="col-sm-7 mb-1"></dd>

                                    <dt class="i18n col-sm-5 text-muted" data-i18n-html="admin_dashboard.session.expires_label"></dt>
                                    <dd id="admin-session-expires" class="col-sm-7 mb-0"></dd>
                                </dl>

                                <div class="d-flex flex-wrap">
                                    <button
                                        type="button"
                                        id="admin-session-refresh"
                                        class="i18n btn btn-info btn-sm rounded-0 mr-2 mb-2 cp"
                                        data-i18n-html="admin_dashboard.session.refresh_btn"></button>
                                    <button
                                        type="button"
                                        id="admin-session-credentials-clear"
                                        class="i18n btn btn-outline-danger btn-sm rounded-0 mb-2 cp"
                                        data-i18n-html="admin_dashboard.settings.clear_credentials"></button>
                                </div>

                                <p id="admin-session-refresh-status" class="small mt-2 mb-0" role="status" aria-live="polite" hidden></p>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-lg-6 mb-4">
                        <div class="card rounded-0 h-100 border">
                            <div class="card-header bg-white d-flex align-items-center justify-content-between py-2">
                                <span class="i18n small font-weight-bold" data-i18n-html="admin_dashboard.session.diagnostics_title"></span>
                                <button
                                    type="button"
                                    id="admin-session-diagnostics-refresh"
                                    class="i18n btn btn-outline-secondary btn-sm rounded-0 cp"
                                    data-i18n-html="admin_dashboard.session.reload_diagnostics"></button>
                            </div>
                            <div class="card-body p-3">
                                <pre id="admin-session-diagnostics" class="admin-session-diagnostics small bg-light border p-2 mb-0"></pre>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- VIEW 5: CREDENCIAIS -->
            <section id="admin-view-credentials" class="admin-view" hidden>

                <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between mb-3 pb-3 border-bottom">
                    <div class="mb-2 mb-md-0">
                        <h2 class="h4 mb-1">Credenciais</h2>
                        <p class="text-muted small mb-0">
                            Gerencie suas chaves e os JWTs associados.
                        </p>
                    </div>

                    <div class="d-flex flex-wrap align-items-center">
                        <input
                            type="file"
                            id="admin-credentials-import-file"
                            accept=".json,application/json"
                            hidden>

                        <button
                            type="button"
                            id="admin-credentials-import"
                            class="btn btn-outline-secondary btn-sm rounded-0 px-3 mr-2 mb-2 mb-md-0">
                            Importar
                        </button>

                        <button
                            type="button"
                            id="admin-credentials-export-all"
                            class="btn btn-outline-primary btn-sm rounded-0 px-3 mr-2 mb-2 mb-md-0">
                            Exportar tudo
                        </button>

                        <button
                            type="button"
                            id="admin-credentials-new"
                            class="btn btn-info btn-sm rounded-0 px-3 mb-2 mb-md-0">
                            Nova credencial
                        </button>
                    </div>
                </div>

                <!-- RESUMO -->
                <div class="mb-3">
                    <span class="small text-muted">
                        Credenciais cadastradas:
                        <strong id="admin-credentials-count">0</strong>
                    </span>
                </div>

                <!-- FEEDBACK DAS OPERAÇÕES -->
                <div
                    id="admin-credentials-feedback"
                    class="alert rounded-0 small mb-3"
                    role="status"
                    aria-live="polite"
                    hidden>
                </div>

                <!-- LISTAGEM -->
                <div id="admin-credentials-list" class="row"></div>

                <!-- ESTADO VAZIO -->
                <div
                    id="admin-credentials-empty"
                    class="p-4 text-center border bg-white text-muted small">
                    <div class="mb-2">
                        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true">
                            <circle cx="8" cy="15" r="5"></circle>
                            <path d="m10.5 11.5 9-9"></path>
                            <path d="M16 5l3 3"></path>
                            <path d="M13 8l3 3"></path>
                        </svg>
                    </div>
                    <p class="mb-0">
                        Nenhuma credencial cadastrada.
                    </p>
                </div>

            </section>

            <!-- VIEW 6: REGISTROS -->
            <section id="admin-view-records" class="admin-view" hidden>

                <div class="mb-3 pb-3 border-bottom">

                    <h2 class="h4 mb-1">
                        Registros
                    </h2>

                    <p class="text-muted small mb-0">
                        Consulte os registros armazenados no serviço.
                    </p>

                </div>

                <nav class="nav nav-tabs mb-3"
                     role="tablist">

                    <button
                        type="button"
                        class="nav-link active"
                        data-records-tab="analytics"
                        role="tab"
                        aria-selected="true">
                        Analíticos
                        <span class="badge badge-secondary ml-1"
                              data-records-count="analytics">—</span>
                    </button>

                    <button
                        type="button"
                        class="nav-link"
                        data-records-tab="feedback"
                        role="tab"
                        aria-selected="false">
                        Feedback
                        <span class="badge badge-secondary ml-1"
                              data-records-count="feedback">—</span>
                    </button>

                    <button
                        type="button"
                        class="nav-link"
                        data-records-tab="errors"
                        role="tab"
                        aria-selected="false">
                        Erros
                        <span class="badge badge-secondary ml-1"
                              data-records-count="errors">—</span>
                    </button>

                </nav>

                <!-- ANALYTICS -->
                <div data-records-panel="analytics"
                     role="tabpanel">

                    <div data-records-list="analytics"></div>

                    <div data-records-pagination="analytics"
                         class="mt-3"></div>

                </div>

                <!-- FEEDBACK -->
                <div data-records-panel="feedback"
                     role="tabpanel"
                     hidden>

                    <div data-records-list="feedback"></div>

                    <div data-records-pagination="feedback"
                         class="mt-3"></div>

                </div>

                <!-- ERRORS -->
                <div data-records-panel="errors"
                     role="tabpanel"
                     hidden>

                    <div data-records-list="errors"></div>

                    <div data-records-pagination="errors"
                         class="mt-3"></div>

                </div>

            </section>

            <!-- VIEW 7: DEVTOOLS -->
            <section id="admin-view-devtools" class="admin-view" hidden>

                <div class="mb-3 pb-3 border-bottom">
                    <h2 class="i18n h4 mb-1" data-i18n-html="admin_dashboard.devtools.title">DevTools</h2>
                    <p class="i18n text-muted small mb-0" data-i18n-html="admin_dashboard.devtools.subtitle"></p>
                </div>

                <div class="row">

                    <!-- INDEXEDDB -->
                    <div class="col-12 mb-4">
                        <div class="card rounded-0 border">
                            <div class="card-header bg-white py-2">
                                <h3 class="i18n h6 mb-0" data-i18n-html="admin_dashboard.devtools.indexeddb.title">IndexedDB</h3>
                            </div>
                            <div class="card-body">
                                <div id="admin-devtools-indexeddb" class="small">
                                    <p class="i18n text-muted mb-0" data-i18n-html="admin_dashboard.devtools.loading"></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- LOCAL STORAGE -->
                    <div class="col-12 col-lg-6 mb-4">
                        <div class="card rounded-0 h-100 border">
                            <div class="card-header bg-white py-2">
                                <h3 class="i18n h6 mb-0" data-i18n-html="admin_dashboard.devtools.local_storage.title">Local Storage</h3>
                            </div>
                            <div class="card-body">
                                <div id="admin-devtools-local-storage" class="small">
                                    <p class="i18n text-muted mb-0" data-i18n-html="admin_dashboard.devtools.loading"></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- CACHE STORAGE -->
                    <div class="col-12 col-lg-6 mb-4">
                        <div class="card rounded-0 h-100 border">
                            <div class="card-header bg-white py-2">
                                <h3 class="i18n h6 mb-0" data-i18n-html="admin_dashboard.devtools.cache_storage.title">Cache Storage</h3>
                            </div>
                            <div class="card-body">
                                <div id="admin-devtools-cache-storage" class="small">
                                    <p class="i18n text-muted mb-0" data-i18n-html="admin_dashboard.devtools.loading"></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- COOKIES -->
                    <div class="col-12 mb-4">
                        <div class="card rounded-0 border">
                            <div class="card-header bg-white py-2">
                                <h3 class="i18n h6 mb-0" data-i18n-html="admin_dashboard.devtools.cookies.title">Cookies</h3>
                            </div>
                            <div class="card-body">
                                <div id="admin-devtools-cookies" class="small">
                                    <p class="i18n text-muted mb-0" data-i18n-html="admin_dashboard.devtools.loading"></p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </section>

        </main>
    </div>

    <!-- ==================================================
         MODAL: CRIAR CREDENCIAL
    =================================================== -->
    <div
        class="modal fade"
        id="admin-modal-credential-create"
        tabindex="-1"
        role="dialog"
        aria-labelledby="admin-modal-credential-create-title"
        aria-hidden="true">

        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content rounded-0">

                <form id="admin-form-credential-create">

                    <div class="modal-header">
                        <h5
                            id="admin-modal-credential-create-title"
                            class="modal-title">
                            Nova credencial
                        </h5>

                        <button
                            type="button"
                            class="close"
                            data-dismiss="modal"
                            aria-label="Fechar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">

                        <p class="text-muted small">
                            Informe um nome e uma descrição para identificar esta chave.
                            O identificador KID será gerado automaticamente.
                        </p>

                        <div class="form-group">
                            <label for="admin-credential-name">
                                Nome
                            </label>

                            <input
                                type="text"
                                id="admin-credential-name"
                                name="name"
                                class="form-control rounded-0"
                                maxlength="100"
                                autocomplete="off"
                                required>
                        </div>

                        <div class="form-group mb-0">
                            <label for="admin-credential-description">
                                Descrição
                            </label>

                            <textarea
                                id="admin-credential-description"
                                name="description"
                                class="form-control rounded-0"
                                rows="3"
                                maxlength="500"
                                required></textarea>
                        </div>

                    </div>

                    <div class="modal-footer">
                        <button
                            type="button"
                            class="btn btn-outline-secondary btn-sm rounded-0"
                            data-dismiss="modal">
                            Cancelar
                        </button>

                        <button
                            type="submit"
                            id="admin-credential-create-submit"
                            class="btn btn-info btn-sm rounded-0">
                            Criar credencial
                        </button>
                    </div>

                </form>

            </div>
        </div>
    </div>

    <!-- ==================================================
         MODAL: CRIAR JWT
    =================================================== -->
    <div
        class="modal fade"
        id="admin-modal-token-create"
        tabindex="-1"
        role="dialog"
        aria-labelledby="admin-modal-token-create-title"
        aria-hidden="true">

        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content rounded-0">

                <form id="admin-form-token-create">

                    <div class="modal-header">
                        <h5
                            id="admin-modal-token-create-title"
                            class="modal-title">
                            Gerar JWT
                        </h5>

                        <button
                            type="button"
                            class="close"
                            data-dismiss="modal"
                            aria-label="Fechar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">

                        <input
                            type="hidden"
                            id="admin-token-kid"
                            name="kid">

                        <div class="form-group">
                            <label for="admin-token-name">
                                Nome
                            </label>

                            <input
                                type="text"
                                id="admin-token-name"
                                name="name"
                                class="form-control rounded-0"
                                maxlength="100"
                                autocomplete="off"
                                required>
                        </div>

                        <div class="form-group">
                            <label for="admin-token-description">
                                Descrição
                            </label>

                            <textarea
                                id="admin-token-description"
                                name="description"
                                class="form-control rounded-0"
                                rows="3"
                                maxlength="500"
                                required></textarea>
                        </div>

                        <div class="form-group">
                            <label for="admin-token-audience">
                                Serviço (Audience)
                            </label>

                            <select
                                id="admin-token-audience"
                                name="aud"
                                class="form-control rounded-0"
                                required>
                                <option value="" selected disabled>
                                    Selecione um serviço
                                </option>
                            </select>

                            <small class="form-text text-muted">
                                Selecione um dos serviços configurados no sistema.
                            </small>
                        </div>

                        <div class="form-group mb-0">
                            <label for="admin-token-expires">
                                Validade
                            </label>

                            <select
                                id="admin-token-expires"
                                name="expiresIn"
                                class="form-control rounded-0"
                                required>

                                <option value="8h" selected>
                                    8 horas (padrão)
                                </option>

                                <option value="6m">
                                    6 meses
                                </option>

                                <option value="1y">
                                    1 ano
                                </option>

                            </select>
                        </div>

                    </div>

                    <div class="modal-footer">
                        <button
                            type="button"
                            class="btn btn-outline-secondary btn-sm rounded-0"
                            data-dismiss="modal">
                            Cancelar
                        </button>

                        <button
                            type="submit"
                            id="admin-token-create-submit"
                            class="btn btn-info btn-sm rounded-0">
                            Gerar JWT
                        </button>
                    </div>

                </form>

            </div>
        </div>
    </div>

    <!-- ==================================================
         MODAL: EDITAR METADADOS
         Utilizado para credenciais e JWTs antigos.
    =================================================== -->
    <div
        class="modal fade"
        id="admin-modal-metadata"
        tabindex="-1"
        role="dialog"
        aria-labelledby="admin-modal-metadata-title"
        aria-hidden="true">

        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content rounded-0">

                <form id="admin-form-metadata">

                    <div class="modal-header">
                        <h5
                            id="admin-modal-metadata-title"
                            class="modal-title">
                            Editar identificação
                        </h5>

                        <button
                            type="button"
                            class="close"
                            data-dismiss="modal"
                            aria-label="Fechar">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">

                        <input
                            type="hidden"
                            id="admin-metadata-type"
                            name="type">

                        <input
                            type="hidden"
                            id="admin-metadata-kid"
                            name="kid">

                        <input
                            type="hidden"
                            id="admin-metadata-jti"
                            name="jti">

                        <div class="form-group">
                            <label for="admin-metadata-name">
                                Nome
                            </label>

                            <input
                                type="text"
                                id="admin-metadata-name"
                                name="name"
                                class="form-control rounded-0"
                                maxlength="100"
                                autocomplete="off"
                                required>
                        </div>

                        <div class="form-group mb-0">
                            <label for="admin-metadata-description">
                                Descrição
                            </label>

                            <textarea
                                id="admin-metadata-description"
                                name="description"
                                class="form-control rounded-0"
                                rows="3"
                                maxlength="500"
                                required></textarea>
                        </div>

                        <small class="form-text text-muted mt-3">
                            Esta operação altera somente a identificação local.
                            Não modifica a chave criptográfica nem o conteúdo do JWT.
                        </small>

                    </div>

                    <div class="modal-footer">
                        <button
                            type="button"
                            class="btn btn-outline-secondary btn-sm rounded-0"
                            data-dismiss="modal">
                            Cancelar
                        </button>

                        <button
                            type="submit"
                            id="admin-metadata-submit"
                            class="btn btn-info btn-sm rounded-0">
                            Salvar alterações
                        </button>
                    </div>

                </form>

            </div>
        </div>
    </div>

    <!-- ==================================================
         MODAL: CONFIRMAR EXCLUSÃO
         Usado para excluir JWT ou credencial completa.
    =================================================== -->
    <div
        class="modal fade"
        id="admin-modal-confirm"
        tabindex="-1"
        role="dialog"
        aria-labelledby="admin-modal-confirm-title"
        aria-hidden="true">

        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content rounded-0">

                <div class="modal-header">
                    <h5
                        id="admin-modal-confirm-title"
                        class="modal-title">
                        Confirmar exclusão
                    </h5>

                    <button
                        type="button"
                        class="close"
                        data-dismiss="modal"
                        aria-label="Fechar">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <input
                        type="hidden"
                        id="admin-confirm-type"
                        name="type">

                    <input
                        type="hidden"
                        id="admin-confirm-kid"
                        name="kid">

                    <input
                        type="hidden"
                        id="admin-confirm-jti"
                        name="jti">

                    <p
                        id="admin-modal-confirm-message"
                        class="mb-0">
                        Deseja realmente excluir este registro?
                    </p>
                </div>

                <div class="modal-footer">
                    <button
                        type="button"
                        class="btn btn-outline-secondary btn-sm rounded-0"
                        data-dismiss="modal">
                        Cancelar
                    </button>

                    <button
                        type="button"
                        id="admin-confirm-submit"
                        class="btn btn-danger btn-sm rounded-0">
                        Excluir
                    </button>
                </div>

            </div>
        </div>
    </div>

    <!-- ==================================================
         MODAL: CONFIRMAR AÇÃO DO DEVTOOLS
         Usado para confirmar exclusões no painel DevTools.
    =================================================== -->
    <div
        class="modal fade"
        id="admin-modal-devtools-confirm"
        tabindex="-1"
        role="dialog"
        aria-labelledby="admin-modal-devtools-confirm-title"
        aria-hidden="true">

        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content rounded-0">

                <div class="modal-header">
                    <h5
                        id="admin-modal-devtools-confirm-title"
                        class="modal-title">
                        Confirmar exclusão
                    </h5>

                    <button
                        type="button"
                        class="close"
                        data-dismiss="modal"
                        aria-label="Fechar">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <p
                        id="admin-modal-devtools-confirm-message"
                        class="mb-2">
                        Deseja realmente executar esta ação?
                    </p>

                    <p
                        id="admin-modal-devtools-confirm-target"
                        class="small font-weight-bold text-monospace bg-light border p-2 mb-0 text-break"
                        hidden></p>

                    <div
                        id="admin-modal-devtools-confirm-warning"
                        class="alert alert-warning rounded-0 small mt-3 mb-0"
                        role="alert"
                        hidden>
                        Esta ação apagará todos os dados locais da aplicação (sessão do GitHub, credenciais, rascunhos e preferências) e a página será recarregada automaticamente.
                    </div>

                    <div
                        id="admin-modal-devtools-confirm-error"
                        class="alert alert-danger rounded-0 small mt-3 mb-0"
                        role="alert"
                        hidden></div>
                </div>

                <div class="modal-footer">
                    <button
                        type="button"
                        id="admin-devtools-confirm-cancel"
                        class="btn btn-outline-secondary btn-sm rounded-0"
                        data-dismiss="modal">
                        Cancelar
                    </button>

                    <button
                        type="button"
                        id="admin-devtools-confirm-submit"
                        class="btn btn-danger btn-sm rounded-0">
                        Excluir
                    </button>
                </div>

            </div>
        </div>
    </div>

    <!-- MENSAGENS INTERNAS TRADUZÍVEIS -->
    <div id="admin-dashboard-messages" hidden>
        <span class="i18n" data-msg="clear_confirm" data-i18n-html="admin_dashboard.session.clear_confirm"></span>
        <span class="i18n" data-msg="status_active" data-i18n-html="admin_dashboard.session.status_active"></span>
        <span class="i18n" data-msg="status_expiring" data-i18n-html="admin_dashboard.session.status_expiring"></span>
        <span class="i18n" data-msg="status_expired" data-i18n-html="admin_dashboard.session.status_expired"></span>
        <span class="i18n" data-msg="status_no_expiry" data-i18n-html="admin_dashboard.session.status_no_expiry"></span>
        <span class="i18n" data-msg="refreshing" data-i18n-html="admin_dashboard.session.refreshing"></span>
        <span class="i18n" data-msg="refreshed" data-i18n-html="admin_dashboard.session.refreshed"></span>
        <span class="i18n" data-msg="refresh_failed" data-i18n-html="admin_dashboard.session.refresh_failed"></span>
        <span class="i18n" data-msg="reauth_needed" data-i18n-html="admin_dashboard.session.reauth_needed"></span>
        <span class="i18n" data-msg="diagnostics_empty" data-i18n-html="admin_dashboard.session.diagnostics_empty"></span>
        <span class="i18n" data-msg="diagnostics_error" data-i18n-html="admin_dashboard.session.diagnostics_error"></span>
    </div>

</section>
<!-- END ADMIN DASHBOARD -->