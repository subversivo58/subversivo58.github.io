/**
 * @file Controller.mjs
 * @description Controller class that coordinates model and view logic.
 * @license The MIT License (MIT) - [https://github.com/subversivo58/subversivo58.github.io/blob/master/LICENSE]
 * @copyright Copyright (c) 2010-2026 Lauro Moraes - [https://github.com/subversivo58]
 * @version 0.1.0 [development stage]
 */
import _, {
    IsWebBrowserContext,
    IsWebWorkerContext,
    IsServiceWorkerContext,
    noop, dc, wd, nv, sw, ua, ls, ss, ot, dt, ts,
    // PHP time() approach
    time,
    // protocol
    uri,
    // root (domain)
    BaseRoot,
    // XMLHttpRequest
    XHR,
    // FormData
    FD,
    // global get APIS...
    indexedDB,
    IDBTransaction,
    IDBKeyRange,
    URL,
    Geolocation,
    RegLogout,
    Notifics,
    Fetch,
    Storage,
    Worker,
    ServiceWorker,
    Promise
} from '../helpers/Exporter.mjs'
import PolicyHandler from './PolicyHandler.mjs'



export default class Controller {
    /**
     * Creates the controller and its policy handler.
     */
    constructor() {
        this.policy = new PolicyHandler('Controller')
    }

    /**
     * Logs the permissions of the browser for the cookies policy.
     * @description For diagnostic purposes.
     */
    Cookies() {
        this.policy.getAllPermissions().then(list => {
            console.log(list)
        })
    }

    /**
     * Logs the state of the persistent storage permission.
     * @description For diagnostic purposes.
     */
    Storage() {
        this.policy.getPermission('persistent-storage').then(response => {
            console.log(response)
        })
    }
}