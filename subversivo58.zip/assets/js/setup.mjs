/**
 * @file setup.mjs
 * @description Application entry point: loads settings, opens the database, loads modules and initializes the page.
 * @license The MIT License (MIT) - [https://github.com/subversivo58/subversivo58.github.io/blob/master/LICENSE]
 * @copyright Copyright (c) 2010-2026 Lauro Moraes - [https://github.com/subversivo58]
 * @version 0.1.0 [development stage]
 */
"use strict";

import "./modules/lib/DebugConsole.mjs";

const settingsResponse = await fetch(
    new URL("../../config/settings.json", import.meta.url),
    {
        cache: "no-store"
    }
);

if (!settingsResponse.ok) {
    throw new Error(
        `[SETUP]: Failed to load settings.json (${settingsResponse.status})`
    );
}

const settings = await settingsResponse.json();

// helpers
import _, {
    IsWebBrowserContext,
    IsWebWorkerContext,
    IsServiceWorkerContext,
    IsFrameBox,
    noop,
    dc,
    wd,
    nv,
    sw,
    ua,
    ls,
    ss,
    ot,
    dt,
    ts,
    // PHP time() approach
    time,
    // protocol
    uri,
    // root (domain)
    BaseRoot,
    // XMLHttpRequest
    XHR,
    // FormData
    FD,
    // global get APIS...
    indexedDB,
    IDBTransaction,
    IDBKeyRange,
    URL,
    Geolocation,
    RegLogout,
    Notifics,
    Fetch,
    Storage,
    Worker,
    ServiceWorker,
    Promise
} from "./modules/helpers/Exporter.mjs";

// functions
import {
    Bytes2Size,
    DeepFreeze,
    DeepEqual,
    StringDistance,
    FindAndReplace,
    Queue,
    Stack,
    PathName,
    DirsLevel,
    Redirect,
    SendBeacon,
    ColorPallet,
    TimeLength,
    TimeAgo,
    ReadingTextTime,
    AnchorScrool,
    SoundPlay,
    BrightnessDetector,
    SpyDOM,
    PressHoldCollorCharger
} from "./modules/functions/Functions.mjs";

let GitHubAPIInstance = null;

// vendors
import BootstrapNative from "./modules/vendor/bootstrap-native.mjs";

// LazyLoadImage
import LazyLoad from "./modules/lib/LazyLoad.mjs";

// libs
import {
    Emitter,
    CryptoHandler,
    AWCookies,
    AWStorage,
    AWCache,
    AWClearBrowserStoragement,
    AWIndexedDB,
    IlibJS
} from "./modules/lib/Exporter.mjs";

if (!navigator.cookieEnabled && PathName(true) !== "nocookie") {
    location.replace("/nocookie.html");
}

const LocalStorage = AWStorage();

const THEME_STORAGE_KEY = "theme";

/**
 * Normalizes a theme name to "light" or "dark". Any other value becomes "light".
 * @param {*} value
 * @return {"light"|"dark"}
 */
const normalizeTheme = value => (value === "dark" ? "dark" : "light");

/**
 * Reads the theme saved in local storage.
 * @return {"light"|"dark"} "light" when nothing is saved or storage is unavailable.
 */
const getSavedTheme = () => {
    try {
        return normalizeTheme(LocalStorage.get(THEME_STORAGE_KEY));
    } catch (error) {
        return "light";
    }
};

/**
 * Updates the theme buttons of the drawer (pressed state and visibility).
 * @param {string} theme
 */
const syncDrawerThemeButtons = theme => {
    const normalized = normalizeTheme(theme);
    const darkBtn = dc.getElementById("drawer-theme-dark");
    const lightBtn = dc.getElementById("drawer-theme-light");

    if (darkBtn) {
        darkBtn.classList.toggle("d-none", normalized === "dark");
        darkBtn.setAttribute("aria-pressed", String(normalized === "dark"));
    }

    if (lightBtn) {
        lightBtn.classList.toggle("d-none", normalized === "light");
        lightBtn.setAttribute("aria-pressed", String(normalized === "light"));
    }
};

/**
 * Applies a theme to the document: the data-theme attribute, the theme-dark class, color-scheme and the theme-color meta tag.
 * @param {string} theme
 * @param {Object} [options={}]
 * @param {boolean} [options.persist=false] - Saves the choice in local storage.
 */
const applyTheme = (theme, { persist = false } = {}) => {
    const normalized = normalizeTheme(theme);

    dc.documentElement.dataset.theme = normalized;
    dc.documentElement.classList.toggle("theme-dark", normalized === "dark");
    dc.documentElement.style.colorScheme = normalized;

    const themeColorMeta = dc.querySelector('meta[name="theme-color"]');
    if (themeColorMeta) {
        if (!themeColorMeta.dataset.lightColor) {
            themeColorMeta.dataset.lightColor =
                themeColorMeta.getAttribute("content") || "#1ebfff";
        }
        themeColorMeta.setAttribute(
            "content",
            normalized === "dark"
                ? "#1a2027"
                : themeColorMeta.dataset.lightColor
        );
    }

    syncDrawerThemeButtons(normalized);

    if (persist) {
        try {
            LocalStorage.set(THEME_STORAGE_KEY, normalized);
        } catch (error) {
            console.error("[THEME]: could not save theme preference", error);
        }
    }

    return normalized;
};

applyTheme(getSavedTheme());

import PolicyHandler from "./modules/models/PolicyHandler.mjs";

import Templates from "./modules/models/Templates.mjs";

import {
    renderFooterNews,
    renderIndexCarousel
} from "./modules/models/RecentPosts.mjs";

import indexedDBLogs from "./modules/lib/IndexedLogs.mjs";

import Analytics from "./modules/lib/Analytics.mjs";

import { DrawerEvents, SlideMenus } from "./modules/models/UIHandler.mjs";

// logging
const SetupLog = new indexedDBLogs("[SETUP]: ");

const FORM_STATUS = {
    "bugs-report-form": {
        ok: "drawer.bug_report.sent",
        fail: "drawer.bug_report.failed"
    },
    "feedback-form": {
        ok: "drawer.feedback.notific.success.message",
        fail: "drawer.feedback.notific.error.message"
    },
    "fats-notes-form": {
        ok: "drawer.notes_form.sent",
        fail: "drawer.notes_form.failed"
    }
};

/**
 * Paints the feedback stars up to the given value.
 * @param {number} value
 */
const paintRating = value => {
    dc.querySelectorAll("#drawer-feedback-block .star-rating").forEach(star => {
        star.textContent = Number(star.dataset.starValue) <= value ? "★" : "☆";
    });
};

/**
 * Sets the value of the feedback rating field. A falsy value clears it.
 * @param {number|null} value
 */
const setRating = value => {
    const input = dc.getElementById("feedback-rating");
    if (!input) return;

    if (value) {
        input.value = String(value);
        input.disabled = false;
    } else {
        input.value = "";
        input.disabled = true;
    }

    paintRating(value || 0);
};

dc.addEventListener("click", event => {
    const star = event.target.closest("#drawer-feedback-block .star-rating");
    if (!star) return;

    const value = Number(star.dataset.starValue);
    const input = dc.getElementById("feedback-rating");
    const current = input && !input.disabled ? Number(input.value) : 0;

    setRating(current === value ? 0 : value);
});

dc.addEventListener("reset", event => {
    if (event.target && event.target.id === "feedback-form") {
        setRating(0);
    }
});


dc.addEventListener("submit", async event => {
    const form = event.target;
    const keys = FORM_STATUS[form.id];

    if (!keys) return;

    event.preventDefault();

    const status = document.getElementById(`${form.id}-status`);

    /**
     * Shows a translated status message with a CSS class.
     * @param {string} key - i18n key of the message.
     * @param {string} cls - CSS class to apply.
     */
    const showStatus = (key, cls) => {
        if (!status) return;
        status.className = `small mt-2 mb-0 i18n ${cls}`;
        status.setAttribute("data-i18n-html", key);
        status.removeAttribute("translated");
        status.hidden = false;
        i18n.transcript();
    };

    if (
        form.id === "feedback-form" ||
        form.id === "bugs-report-form"
    ) {
        const messageField = form.elements.namedItem("message");
        const message = messageField?.value.trim() || "";

        if (form.id === "feedback-form") {
            const ratingField = form.elements.namedItem("rating");
            const rating = Number(ratingField?.value);

            if (
                !Number.isInteger(rating) ||
                rating < 1 ||
                rating > 5
            ) {
                messageField.setCustomValidity(
                    "Selecione uma avaliação de 1 a 5 estrelas."
                );
                messageField.reportValidity();
                messageField.setCustomValidity("");
                return;
            }

            if (message.length < 1 || message.length > 500) {
                messageField.setCustomValidity(
                    "A mensagem deve conter entre 1 e 500 caracteres."
                );
                messageField.reportValidity();
                messageField.setCustomValidity("");
                return;
            }
        }

        if (form.id === "bugs-report-form") {
            const typeField = form.elements.namedItem("type");
            const allowedTypes = [
                "custom",
                "css",
                "javascript",
                "language",
                "plugin",
                "server"
            ];

            if (!allowedTypes.includes(typeField?.value)) {
                typeField?.setCustomValidity(
                    "Selecione um tipo de erro válido."
                );
                typeField?.reportValidity();
                typeField?.setCustomValidity("");
                return;
            }

            if (message.length < 1 || message.length > 280) {
                messageField.setCustomValidity(
                    "A descrição deve conter entre 1 e 280 caracteres."
                );
                messageField.reportValidity();
                messageField.setCustomValidity("");
                return;
            }
        }
    }

    try {
        const response = await fetch(form.action, {
            method: "POST",
            body: new FormData(form)
        });

        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        form.reset();
        if (form.id === "feedback-form") setRating(0);
        showStatus(keys.ok, "text-success");
    } catch (error) {
        console.error("[FORM]:", error);
        showStatus(keys.fail, "text-danger");
    }
});


// IndexedDB manager
const ConnectionDB = new AWIndexedDB(
    settings.database.name,
    settings.database.version,
    noop
);

// Shared database connection
let DBMethods = null;

try {
    DBMethods = await ConnectionDB.open(settings.database.indexed);

    // Inject the shared connection into the logger.
    SetupLog.setConnection(DBMethods);

    SetupLog.success("IndexedDB connection established", {
        database: settings.database.name,
        version: settings.database.version,
        stores: settings.database.indexed.map(item => item.tbn)
    });
} catch (error) {
    console.error("[SETUP]: IndexedDB initialization failed", error);
}

// LifeCycle
import LifeCycle from "./modules/core/LifeCycle.mjs";

const Activity = new LifeCycle();

PolicyHandler.supported = settings.source.language;

const Policy = Activity.create(
    new PolicyHandler("Subversivo58_Policy", SetupLog)
);

Policy.resume();

let SiteAnalytics = null;

if (DBMethods) {
    try {
        const analyticsEnabled = await Policy.loadAnalyticsConsent(DBMethods);

        SiteAnalytics = new Analytics({
            database: DBMethods,
            enable: analyticsEnabled,
            getLanguage: () => PolicyHandler.language
        });

        await SiteAnalytics.initialize();
        Policy.setAnalytics(SiteAnalytics);
    } catch (error) {
        console.error("[ANALYTICS]: Initialization failed", error);
    }

    wd.addEventListener("error", event => {
        const err = event?.error || event?.message || "Uncaught script error";
        SiteAnalytics?.trackError("runtime", err).catch(() => {});
    });

    wd.addEventListener("unhandledrejection", event => {
        const reason = event?.reason || "Unhandled promise rejection";
        SiteAnalytics?.trackError("promise", reason).catch(() => {});
    });
}

let BaseRootRegExp = new RegExp(BaseRoot),
    redirectAfterSetup =
        dc.referrer !== ""
            ? dc.referrer.includes(BaseRoot)
                ? dc.referrer
                : BaseRoot
            : BaseRoot,
    SettingsCFG;

// Instance and "mode" (i18n|l10n|Intl)
const i18n = new IlibJS("i18n");

const Events = new Emitter("setup");

import NotifyJS from "./modules/lib/Notifications.mjs";

import Permissions from "./modules/lib/Permissions.mjs";

const BrowserPermissions = new Permissions();

const Notify = new NotifyJS({
    permissions: BrowserPermissions,
    watchPermissions: true,
    player: SoundPlay,
    translate: key => i18n.getWord(key),
    //logger: NotifyLogger.loging,
    // only for "bootstraped" template
    gui: {
        /**
         * Axis direction: as detected by `isMobile()` detection or all screen less than 576 width
         * rb = right & bottom (default) [for non-mobile view]
         * rt = right & top (default for mobile view)[mobile/desktop]         * lb = left & bottom [for non-mobile view]
         * lt = left & top [mobile/desktop]
         * @type {String}
         */
        axis: "rb",
        /**
         * Order vertical direction: inverted in mobile (mobile show from top to down, desktop show from bottom to up)
         * fl = first last (default) [desktop last is show in first down, mobile is show on first up]
         * fe = first end [desktop last show in top, mobile last show in down]
         * @type {String}
         */
        order: "fl",
        /**
         * User settings: enable or disable user choices (default: enabled all)
         * @note: user choices is precedent as settings: axis, order, sound
         */
        choices: {
            mute: true, // user mute sound (default: true = enabled to choice)
            axis: true, // user choose "axis" ... the same options as axis up
            order: true, // user choose "order" ... the same options as order up
            dir: true, // user choose "text direction" (default left to right) [left to right or right to left]
            /**
             * User choose auto collapse big texts and (or) images
             */
            collapse: {
                text: true,
                image: true
            }
        }
    }
});

/**
 * Change border-bottom of fixed navbar
 * @see  scroll {@link https://stackoverflow.com/questions/4096863/how-to-get-and-set-the-current-web-page-scroll-position#28488360}
 * @revise - change to `IntersectionObserver()` (if disponible)
 * @priority: LESS
 */
_.DOM.waitEl(dc, "#navbar-fixed", list => {
    if (list[0] && _.DOM.isVisible(list[0])) {
        let DocumentTop = 0;
        _.DOM.event(
            wd,
            "scroll",
            function (ev) {
                ev.stopPropagation();
                let observ = dc.documentElement.scrollTop || dc.body.scrollTop;
                if (observ > 10) {
                    _.$("#navbar-fixed").addClass("navbar-box-shadow");
                }
                if (observ < 10) {
                    _.$("#navbar-fixed").removeClass("navbar-box-shadow");
                }
                DocumentTop = observ;
            },
            _.EventOptions(false, true, false)
        );
    }
});

if ("serviceWorker" in navigator) {
    navigator.serviceWorker
        .register("/ServiceWorker.mjs", {
            type: "module"
        })
        .catch(error => {
            console.error("[SW]: Registration failed", error);
            SiteAnalytics?.trackError("service-worker", error).catch(() => {});
        });
}

/**
 * Runs the setup once the DOM is parsed.
 * @description Handles the one-time site data cleanup, triggered by the "?clear-site-data=1" query parameter, and then initializes the page.
 * @param {Event} evt - DOMContentLoaded event.
 */
const SetupDOMReady = async evt => {
    // After HTMLDocument is charged and parsed [don't wait charge stylesheet's, images and subframe's]
    //_.DOM.event(dc, 'DOMContentLoaded', async evt => {

    // One-time browser storage cleanup
    if (location.search === "?clear-site-data=1") {
        // Remove the trigger to prevent repeated execution
        wd.history.replaceState(
            null,
            "",
            wd.location.pathname + wd.location.hash
        );

        try {
            await Policy.refuseStoragement(true);

            console.log("[SETUP]: Browser storagement cleared");
        } catch (error) {
            console.error("[SETUP]: Browser storagement cleanup failed", error);
        }

        wd.location.reload();
        return;
    }

    // this route
    const router = PathName(true);

    const postCodeEnhancementsPromise =
        router === "post"
            ? (async () => {
                  const box = dc.getElementById("index-central-block");
                  if (!box) return;
                  try {
                      const [{ highlightCodeBlocks }, { default: CodeCopy }] =
                          await Promise.all([
                              import("./modules/lib/Highlight.mjs"),
                              import("./modules/lib/CodeCopy.mjs")
                          ]);
                      highlightCodeBlocks(box, {
                          autoDetect: true,
                          normalizeBarePre: true
                      });
                      const codeCopy = CodeCopy(
                          "#index-central-block",
                          "#code-copy-wrapper-template"
                      );
                      codeCopy();
                  } catch (error) {
                      console.error(
                          "[POST]: Failed to highlight code blocks.",
                          error
                      );
                  }

                  box.addEventListener("click", async event => {
                      const button = event.target.closest("[data-code-copy]");
                      if (!button || !box.contains(button)) return;

                      const wrapper = button.closest(".code-container");
                      const code = wrapper?.querySelector("pre code");
                      if (!code) return;

                      try {
                          await navigator.clipboard.writeText(code.textContent);
                          const originalContent = button.textContent;
                          button.textContent = "✓";
                          button.classList.add("is-copied");
                          setTimeout(() => {
                              button.textContent = originalContent;
                              button.classList.remove("is-copied");
                          }, 1200);
                      } catch (error) {
                          console.error("[POST]: Failed to copy code.", error);
                      }
                  });
              })()
            : Promise.resolve();

    PolicyHandler.supported = settings.source.language;
    dc.documentElement.lang = PolicyHandler.language;
    await i18n
        .get(`/assets/lang/${PolicyHandler.language}.json`, {
            credentials: "include",
            cache: "reload"
        })
        .catch(error => {
            SiteAnalytics?.trackError("i18n", error).catch(() => {});
            throw error;
        });

    const TemplatesReady = new Templates(
        settings.templates,
        {
            rule: [
                "full_year",
                "source_version_canonical",
                "disable_on_policy"
            ],
            replacement: [
                new Date().getFullYear(),
                settings.source.version.canonical,
                function () {
                    return router === "policy" ? 'disabled="disabled"' : "";
                }
            ]
        },
        i18n,
        SiteAnalytics
    );

    TemplatesReady.import.catch(error => {
        SiteAnalytics?.trackError("templates", error).catch(() => {});
    });

    // lazy-load instance
    const lazyLoad = new LazyLoad("undefined");
    // @revise - move this to PolicyInspector.mjs class constructor
    // @priority: MODERATE
    /**
     * Checks the data storage policy cookie and shows the notification when it is missing.
     * @description The notification is shown only when the __DSPolicy__ cookie is not set.
     */
    const DataStoragePolicy = () => {
        AWCookies.get("__DSPolicy__").catch(() => {
            // @revise defaulted "english" message
            // @priority: HIGH
            const DSNotify = new NotifyJS({
                permissions: BrowserPermissions,
                watchPermissions: false
            });
            // action event
            DSNotify.on("click", data => {
                if ("action" in data) {
                    switch (data.action) {
                        case "cookie-agree":
                            Redirect("/policy.html#cookie-agree");
                            break;
                        case "cookie-policy":
                            Redirect("/policy.html#policy-general");
                            break;
                        case "terms-policy":
                            Redirect("/policy.html#policy-terms");
                            break;
                    }
                }
            });

            let NotifyI18nStorage = i18n.dictionary().notify.storage;
            // @revise - create notification and show ()
            const DSNoticeTag = "ds-policy-notice";

            DSNotify.create({
                title: NotifyI18nStorage.title,
                body: NotifyI18nStorage.body,
                badage: "/assets/media/image/icons/badage-monochrome.webp",
                actions: NotifyI18nStorage.actions,
                tag: DSNoticeTag,
                bootstrap: {
                    pinned: false
                }
            }).show();

            // Dismiss automatically after a while; the user can also close it with ✖️
            setTimeout(() => {
                const closeButton = dc.querySelector(
                    `small[data-target="${DSNoticeTag}"]`
                );
                if (closeButton) closeButton.click();
            }, 15000);
        });
    };

    [...dc.querySelectorAll(".parallax")].forEach(obj => {
        let speed = obj.dataset.parallaxSpeed || 3;
        wd.addEventListener(
            "scroll",
            evt => {
                let yPos =
                    2 *
                    ((wd.pageYOffset || dc.body.scrollTop) / speed).toFixed(2);
                obj.style.backgroundPosition = "0 -" + yPos + "px";
            },
            _.EventOptions(false, true, false)
        );
    });

    dc.addEventListener("click", async evt => {
        if (evt.target.closest("#drawer-language-selector")) {
            const current = PolicyHandler.language;
            dc.querySelectorAll(".change-language").forEach(item => {
                item.classList.toggle("border", item.id === current);
                item.classList.toggle("border-info", item.id === current);
            });
            return;
        }

        const option = evt.target.closest(".change-language");

        if (!option || !settings.source.language.includes(option.id)) {
            return;
        }

        try {
            await AWCookies.set("i18n", option.id, {
                expire: 365,
                secure: wd.location.protocol === "https:"
            });
            wd.location.reload();
        } catch (error) {
            console.error("[SETUP]: could not save the language cookie", error);
            SiteAnalytics?.trackError("i18n-cookie", error).catch(() => {});
        }
    });

    dc.addEventListener("click", evt => {
        const trigger = evt.target.closest(
            "#drawer-theme-dark, #drawer-theme-light"
        );
        if (!trigger) return;

        const nextTheme = trigger.id === "drawer-theme-dark" ? "dark" : "light";
        applyTheme(nextTheme, { persist: true });
    });

    _.DOM.waitEl(dc, "#drawer-theme", () => {
        syncDrawerThemeButtons(dc.documentElement.dataset.theme);
    });

    // router
    switch (router) {
        case "index":
        case "dpo":
        case "about":
        case "admin":
        case "blog":
        case "post":
        case "404":
        case "nocookie": {
            // check URI "search" fragment
            if (location.search === "?utm_source=homescreen") {
                // is pwa launch ... register log
            }

            await TemplatesReady.import;
            const adminShortcut = dc.getElementById("drawer-admin");
            let adminAuth = false;

            if (DBMethods) {
                try {
                    const storedAuth = await DBMethods.read({
                        tbn: "github",
                        tbk: "user-github"
                    });

                    adminAuth = Boolean(
                        storedAuth?.user && storedAuth?.tokens?.access_token
                    );
                } catch (error) {
                    console.error(
                        "[ADMIN]: Não foi possível consultar a autenticação.",
                        error
                    );
                }
            }

            if (adminShortcut && adminAuth) {
                adminShortcut.classList.remove("d-none");
            }

            if (router === "index") {
                renderIndexCarousel(
                    settings,
                    document.getElementById("index-central-block"),
                    {
                        locale: PolicyHandler.language,
                        translate: key => i18n.getWord(key),
                        analytics: SiteAnalytics
                    }
                );
            }

            /**
             * Escapes the characters &, <, > and " for safe HTML insertion.
             * @param {*} text
             * @return {string}
             */
            const escHTML = text =>
                String(text ?? "").replace(
                    /[&<>"]/g,
                    char =>
                        ({
                            "&": "&amp;",
                            "<": "&lt;",
                            ">": "&gt;",
                            '"': "&quot;"
                        })[char]
                );

            const AUTHOR_CACHE_PREFIX = "subversivo58:author:";

            /**
             * Reads a cached author from sessionStorage.
             * @param {string} key - Author identifier.
             * @return {Object|null}
             */
            const readAuthorCache = key => {
                try {
                    const raw = sessionStorage.getItem(
                        AUTHOR_CACHE_PREFIX + key
                    );
                    return raw ? JSON.parse(raw) : null;
                } catch {
                    return null;
                }
            };

            /**
             * Saves an author in sessionStorage. Failures are ignored and the page works without the cache.
             * @param {string} key - Author identifier.
             * @param {Object} author
             */
            const writeAuthorCache = (key, author) => {
                try {
                    sessionStorage.setItem(
                        AUTHOR_CACHE_PREFIX + key,
                        JSON.stringify(author)
                    );
                } catch {
                }
            };

            const authorRequests = new Map();

            /**
             * Returns the data of an author, using the cache and sharing requests already in progress.
             * @param {string|number} id - Author identifier.
             * @return {Promise<Object|null>} Resolves with null when there is no identifier.
             */
            const fetchAuthor = id => {
                if (!id) return Promise.resolve(null);

                const key = String(id);
                const cached = readAuthorCache(key);
                if (cached) return Promise.resolve(cached);

                if (authorRequests.has(key)) {
                    return authorRequests.get(key);
                }

                const request = fetch(
                    `https://api.github.com/user/${encodeURIComponent(key)}`,
                    { headers: { Accept: "application/vnd.github+json" } }
                )
                    .then(response => (response.ok ? response.json() : null))
                    .then(user => {
                        if (!user || !user.login) return null;
                        const profile = String(user.html_url || "");
                        return {
                            login: String(user.login),
                            name: String(user.name || user.login),
                            avatar: String(user.avatar_url || ""),
                            url: /^https:\/\/github\.com\//.test(profile)
                                ? profile
                                : `https://github.com/${encodeURIComponent(user.login)}`
                        };
                    })
                    .catch(error => {
                        console.error("[BLOG]: Failed to load author.", error);
                        return null;
                    })
                    .finally(() => {
                        authorRequests.delete(key);
                    });

                authorRequests.set(key, request);

                request.then(author => {
                    if (author) writeAuthorCache(key, author);
                });

                return request;
            };

            /**
             * Formats a timestamp as a localized date using the policy language.
             * @param {number} timestamp
             * @return {string} Empty string when the timestamp is invalid.
             */
            const formatDateLocale = timestamp => {
                if (!timestamp) return "";
                const date = new Date(timestamp);
                if (Number.isNaN(date.getTime())) return "";
                return date.toLocaleDateString(PolicyHandler.language, {
                    dateStyle: "medium"
                });
            };

            if (router === "post") {
                const box = document.getElementById("index-central-block");

                if (box) {
                    box.querySelectorAll("time[datetime]").forEach(el => {
                        const formatted = formatDateLocale(
                            el.getAttribute("datetime")
                        );
                        if (formatted) el.textContent = formatted;
                    });

                    box.querySelectorAll("[data-post-reading-time]").forEach(
                        el => {
                            const mins = Number(el.dataset.postReadingTime);
                            if (Number.isFinite(mins) && mins > 0) {
                                el.textContent = i18n
                                    .getWord("blog.read_time")
                                    .replace("{minutes}", Math.ceil(mins));
                            }
                        }
                    );

                    box.querySelectorAll("[data-post-updated]").forEach(el => {
                        const formatted = formatDateLocale(
                            el.dataset.postUpdated
                        );
                        if (formatted) {
                            el.textContent = i18n
                                .getWord("blog.updated")
                                .replace("{date}", formatted);
                        }
                    });

                    /**
                     * Builds the HTML badge for an author, with the avatar loaded lazily.
                     * @param {Object} author - Author data with name, login and avatar.
                     * @return {string} HTML markup.
                     */
                    const renderAuthorBadge = author => {
                        const displayName = author.name || author.login;
                        return `
                            <span class="blog-author-badge">
                                <picture class="blog-author-avatar-wrap flex-shrink-0">
                                    <img src="/assets/media/image/1x1.gif"
                                         data-src="${escHTML(author.avatar)}"
                                         data-lazy-target
                                         alt="${escHTML(displayName)}"
                                         width="22"
                                         height="22"
                                         class="blog-author-avatar">
                                </picture>
                                <a href="${escHTML(author.url)}"
                                   target="_blank"
                                   rel="noopener noreferrer"
                                   title="@${escHTML(author.login)}"
                                   class="ext-link-icon blog-author-link">${escHTML(displayName)}</a>
                            </span>`;
                    };

                    const authorBox = document.getElementById(
                        "post-author-container"
                    );
                    const metaAuthor = document.querySelector(
                        'meta[name="post-author"]'
                    )?.content;
                    const authorId =
                        authorBox?.dataset.authorId || metaAuthor || "";

                    if (authorBox && authorId) {
                        const author = await fetchAuthor(authorId);
                        if (author) {
                            authorBox.innerHTML = renderAuthorBadge(author);
                            authorBox.classList.remove("d-none");
                            lazyLoad.observe(authorBox);
                        }
                    }

                    await postCodeEnhancementsPromise;

                    lazyLoad.observe(box);
                }
            }

            if (router === "blog") {
                const box = document.getElementById("index-central-block");

                /**
                 * Returns the publication time of a post in milliseconds.
                 * @param {Object} post
                 * @return {number} The timestamp (in ms) or 0 when there is no valid date.
                 * @description Values below 1e12 are treated as seconds.
                 */
                const getPostTimestamp = post => {
                    const timestamp = Number(post.timestamp);
                    if (Number.isFinite(timestamp) && timestamp > 0) {
                        return timestamp > 1e12 ? timestamp : timestamp * 1000;
                    }
                    const date = Number(post.date);
                    return Number.isFinite(date) && date > 0 ? date * 1000 : 0;
                };

                const posts = [...settings.articles.storage].sort(
                    (a, b) => getPostTimestamp(b) - getPostTimestamp(a)
                );
                const maxList =
                    Number(settings.articles["blog-max-list"]) || 10;

                const allTags = [
                    ...new Set(
                        posts
                            .flatMap(p => (Array.isArray(p.tags) ? p.tags : []))
                            .map(t => String(t).trim().toLowerCase())
                            .filter(Boolean)
                    )
                ].sort();

                let activeTag = "";
                let searchQuery = "";
                let visible = maxList;

                if (posts.length === 0) {
                    box.innerHTML = `
                        <div class="container d-flex align-items-center justify-content-center text-center py-5">
                            <div>
                                <div class="display-3 mb-3" aria-hidden="true">📰</div>
                                <p class="i18n lead text-muted mb-0" data-i18n-html="blog.empty">${escHTML(i18n.getWord("blog.empty"))}</p>
                            </div>
                        </div>`;
                } else {
                    /**
                     * Filters the posts by the active tag and the search text.
                     * @return {Object[]}
                     */
                    const getFiltered = () =>
                        posts.filter(post => {
                            const tags = Array.isArray(post.tags)
                                ? post.tags.map(t => String(t).toLowerCase())
                                : [];
                            if (activeTag && !tags.includes(activeTag))
                                return false;
                            if (!searchQuery) return true;
                            const haystack = [
                                post.title,
                                post.summary,
                                post.slug,
                                ...tags
                            ]
                                .join(" ")
                                .toLowerCase();
                            return haystack.includes(searchQuery);
                        });

                    /**
                     * Converts a value in seconds or milliseconds to milliseconds.
                     * @param {number|string} value
                     * @return {number} 0 when the value is invalid.
                     */
                    const normalizeMs = value => {
                        const num = Number(value);
                        if (!Number.isFinite(num) || num <= 0) return 0;
                        return num > 1e12 ? num : num * 1000;
                    };

                    /**
                     * Builds the HTML card of a blog post.
                     * @param {Object} post - Post data.
                     * @return {string} HTML markup.
                     */
                    const cardHTML = post => {
                        const postPath = `/${String(post.path || `posts/${post.slug}.html`).replace(/^\/+/, "")}`;
                        const rawCover =
                            post.cover ||
                            (Array.isArray(post.images) ? post.images[0] : "");
                        const coverUrl = rawCover
                            ? `/${String(rawCover).replace(/^\/+/, "")}`
                            : "/assets/media/image/graph.webp";
                        const publishedMs = getPostTimestamp(post);
                        const modifiedMs = normalizeMs(post.lastModified);
                        const publishedIso = publishedMs
                            ? new Date(publishedMs).toISOString()
                            : "";
                        const modifiedIso = modifiedMs
                            ? new Date(modifiedMs).toISOString()
                            : "";
                        const dateText = formatDateLocale(publishedMs);
                        const updatedFormatted =
                            modifiedMs &&
                            publishedMs &&
                            modifiedMs !== publishedMs
                                ? formatDateLocale(modifiedMs)
                                : "";
                        const updatedText = updatedFormatted
                            ? i18n
                                  .getWord("blog.updated")
                                  .replace("{date}", updatedFormatted)
                            : "";
                        const mins =
                            Number(post.readingTime) > 0
                                ? Math.ceil(Number(post.readingTime))
                                : 1;
                        const readText = i18n
                            .getWord("blog.read_time")
                            .replace("{minutes}", mins);
                        const tags = Array.isArray(post.tags) ? post.tags : [];
                        const authorId = post.author ? String(post.author) : "";

                        return `
                            <div class="col-12 col-md-6 mb-4">
                                <article class="card rounded-0 h-100 border blog-post-card">
                                    <a href="${escHTML(postPath)}" class="d-block blog-post-media">
                                        <picture class="d-block w-100 h-100">
                                            <img src="/assets/media/image/1x1.gif"
                                                 data-src="${escHTML(coverUrl)}"
                                                 data-lazy-target
                                                 alt="${escHTML(post.title)}"
                                                 class="w-100 h-100">
                                        </picture>
                                    </a>
                                    <div class="card-body d-flex flex-column">
                                        ${authorId ? `<div class="mb-2 d-none" data-blog-author="${escHTML(authorId)}"></div>` : ""}
                                        <div class="small text-muted mb-2 blog-post-meta">
                                            <div>
                                                ${dateText ? `<time datetime="${escHTML(publishedIso)}">${escHTML(dateText)}</time>` : ""}
                                                ${dateText ? `<span class="mx-1" aria-hidden="true">&middot;</span>` : ""}
                                                <span>${escHTML(readText)}</span>
                                            </div>
                                            ${updatedText ? `<div class="blog-post-updated" data-post-updated="${escHTML(modifiedIso)}">${escHTML(updatedText)}</div>` : ""}
                                        </div>
                                        <h2 class="h5 font-weight-bold mb-2">
                                            <a href="${escHTML(postPath)}" class="text-dark">${escHTML(post.title)}</a>
                                        </h2>
                                        <p class="small text-muted mb-3 flex-grow-1">${escHTML(post.summary || "")}</p>
                                        ${
                                            tags.length
                                                ? `
                                            <div class="d-flex flex-wrap mb-3">
                                                ${tags.map(tag => `<span class="badge badge-light border mr-1 mb-1 font-weight-normal">${escHTML(tag)}</span>`).join("")}
                                            </div>`
                                                : ""
                                        }
                                        <div class="mt-auto pt-2 border-top">
                                            <a href="${escHTML(postPath)}" class="i18n btn btn-sm btn-outline-info rounded-0 cp" data-i18n-html="blog.read_article">${escHTML(i18n.getWord("blog.read_article"))}</a>
                                        </div>
                                    </div>
                                </article>
                            </div>`;
                    };

                    box.innerHTML = `
                        <div class="container py-3">
                            <header class="d-flex flex-column flex-md-row align-items-md-center justify-content-between mb-4 pb-3 border-bottom">
                                <div class="mb-2 mb-md-0">
                                    <h1 class="i18n h3 mb-0 tc" data-i18n-html="navbar.blog">${escHTML(i18n.getWord("navbar.blog"))}</h1>
                                </div>
                                <div class="w-100" style="max-width: 340px;">
                                    <input type="search"
                                           id="blog-search-input"
                                           class="i18n form-control form-control-sm rounded-0"
                                           data-i18n-place="blog.search_placeholder"
                                           placeholder="${escHTML(i18n.getWord("blog.search_placeholder"))}"
                                           autocomplete="off">
                                </div>
                            </header>

                            ${
                                allTags.length
                                    ? `
                                <div id="blog-tag-filters" class="d-flex flex-wrap align-items-center mb-4">
                                    <button type="button"
                                            data-blog-tag=""
                                            class="i18n btn btn-sm btn-outline-secondary rounded-0 mr-2 mb-2 blog-tag-filter active cp"
                                            data-i18n-html="blog.all_tags">${escHTML(i18n.getWord("blog.all_tags"))}</button>
                                    ${allTags
                                        .map(
                                            tag => `
                                        <button type="button"
                                                data-blog-tag="${escHTML(tag)}"
                                                class="btn btn-sm btn-outline-secondary rounded-0 mr-2 mb-2 blog-tag-filter cp">${escHTML(tag)}</button>
                                    `
                                        )
                                        .join("")}
                                </div>`
                                    : ""
                            }

                            <div id="blog-empty-filter" class="p-4 text-center border bg-light text-muted mb-4" hidden>
                                <span class="i18n" data-i18n-html="blog.no_results">${escHTML(i18n.getWord("blog.no_results"))}</span>
                            </div>

                            <div id="blog-list" class="row"></div>

                            <p id="blog-count" class="small text-muted ct mt-2 mb-0" hidden></p>
                            <button type="button"
                                    id="blog-more"
                                    class="i18n btn btn-outline-secondary btn-block rounded-0 cp mt-3"
                                    data-i18n-html="blog.load_more"
                                    hidden>${escHTML(i18n.getWord("blog.load_more"))}</button>
                        </div>`;

                    const listEl = document.getElementById("blog-list");
                    const emptyEl =
                        document.getElementById("blog-empty-filter");
                    const countEl = document.getElementById("blog-count");
                    const moreEl = document.getElementById("blog-more");
                    const searchInput =
                        document.getElementById("blog-search-input");
                    const tagsWrap =
                        document.getElementById("blog-tag-filters");

                    /**
                     * Loads the data of the authors shown in the visible cards and updates their badges.
                     * @return {void}
                     */
                    const hydrateCardAuthors = () => {
                        const slots = [
                            ...listEl.querySelectorAll("[data-blog-author]")
                        ];
                        const uniqueIds = [
                            ...new Set(
                                slots
                                    .map(el => el.dataset.blogAuthor)
                                    .filter(Boolean)
                            )
                        ];

                        uniqueIds.forEach(async id => {
                            const author = await fetchAuthor(id);
                            if (!author) return;

                            const displayName = author.name || author.login;
                            const badgeHTML = `
                                <span class="blog-author-badge">
                                    <picture class="blog-author-avatar-wrap flex-shrink-0">
                                        <img src="/assets/media/image/1x1.gif"
                                             data-src="${escHTML(author.avatar)}"
                                             data-lazy-target
                                             alt="${escHTML(displayName)}"
                                             width="22"
                                             height="22"
                                             class="blog-author-avatar">
                                    </picture>
                                    <a href="${escHTML(author.url)}"
                                       target="_blank"
                                       rel="noopener noreferrer"
                                       title="@${escHTML(author.login)}"
                                       class="ext-link-icon blog-author-link">${escHTML(displayName)}</a>
                                </span>`;

                            listEl
                                .querySelectorAll("[data-blog-author]")
                                .forEach(slot => {
                                    if (slot.dataset.blogAuthor !== id) return;
                                    slot.innerHTML = badgeHTML;
                                    slot.classList.remove("d-none");
                                });

                            lazyLoad.observe(listEl);
                        });
                    };

                    /**
                     * Renders the posts that match the filters, up to the visible limit.
                     * @return {void}
                     * @description Shows the empty-state message when no post matches.
                     */
                    const renderCatalog = () => {
                        const filtered = getFiltered();
                        const shown = Math.min(visible, filtered.length);

                        if (emptyEl) emptyEl.hidden = filtered.length > 0;
                        listEl.innerHTML = filtered
                            .slice(0, shown)
                            .map(cardHTML)
                            .join("");

                        if (countEl) {
                            countEl.textContent = i18n
                                .getWord("blog.showing")
                                .replace("{shown}", shown)
                                .replace("{total}", filtered.length);
                            countEl.hidden = filtered.length <= maxList;
                        }

                        if (moreEl) {
                            moreEl.hidden = shown >= filtered.length;
                        }

                        hydrateCardAuthors();
                        lazyLoad.observe(listEl);
                    };

                    if (searchInput) {
                        searchInput.addEventListener("input", () => {
                            searchQuery = searchInput.value
                                .trim()
                                .toLowerCase();
                            visible = maxList;
                            renderCatalog();
                        });
                    }

                    if (tagsWrap) {
                        tagsWrap.addEventListener("click", evt => {
                            const btn = evt.target.closest("[data-blog-tag]");
                            if (!btn) return;
                            activeTag = btn.dataset.blogTag || "";
                            tagsWrap
                                .querySelectorAll("[data-blog-tag]")
                                .forEach(el => {
                                    el.classList.toggle("active", el === btn);
                                });
                            visible = maxList;
                            renderCatalog();
                        });
                    }

                    if (moreEl) {
                        moreEl.addEventListener("click", () => {
                            visible += maxList;
                            renderCatalog();
                        });
                    }

                    renderCatalog();
                }
            }

            if (router === "admin") {
                const [
                    { default: WysiwygEditor },
                    { default: GitHubAPI },
                    { default: DeveloperTools },
                    { default: JWTManager },
                    { default: RecordsManager }
                ] = await Promise.all([
                    import("./modules/models/WysiwygEditor.mjs"),
                    import("./modules/lib/GitHubAPI.mjs"),
                    import("./modules/lib/DeveloperTools.mjs"),
                    import("./modules/lib/JWTManager.mjs"),
                    import("./modules/lib/RecordsManager.mjs")
                ]);

                let jwtManager = null;

                try {
                    if (!DBMethods) {
                        throw new Error("Conexão com IndexedDB indisponível.");
                    }

                    jwtManager = new JWTManager({
                        config: settings.jwt,
                        database: DBMethods
                    });

                    await jwtManager.initialize();
                } catch (error) {
                    jwtManager = null;

                    console.error(
                        "[JWT]: Não foi possível inicializar o gerenciamento de credenciais.",
                        error
                    );
                    SiteAnalytics?.trackError("jwt-manager", error).catch(
                        () => {}
                    );
                }

                const DevTools = new DeveloperTools({
                    database: DBMethods,
                    databaseName: settings.database.name,
                    databaseVersion: settings.database.version
                });
                const recordsManager = new RecordsManager({
                    endpoint: settings.jwt?.records?.endpoint,
                    jwtManager,
                    root: dc.getElementById("admin-view-records"),
                    analytics: SiteAnalytics
                });

                recordsManager.initialize();
                const REPOSITORY_OWNER = settings.github_auth.repository_owner;
                const REPOSITORY_NAME = settings.github_auth.repository_name;
                const REPOSITORY_BRANCH = "main";
                const TOKEN_REFRESH_MARGIN_MS = 5 * 60 * 1000;

                /**
                 * Returns a translated message from the GitHub authentication panel.
                 * @param {string} id - Message identifier.
                 * @param {string} [value=""] - Text used when the message is missing.
                 * @return {string}
                 */
                const authMessage = (id, value = "") => {
                    const item = dc.querySelector(
                        `#github-auth-messages [data-msg="${id}"]`
                    );

                    return item
                        ? item.textContent
                              .trim()
                              .split("{0}")
                              .join(String(value))
                        : "";
                };

                /**
                 * Returns a message from the admin dashboard.
                 * @param {string} id - Message identifier.
                 * @return {string}
                 */
                const dashMessage = id => {
                    const item = dc.querySelector(
                        `#admin-dashboard-messages [data-msg="${id}"]`
                    );
                    return item ? item.textContent.trim() : "";
                };

                const modal = dc.getElementById("modal-github-auth");
                const statusElement = dc.getElementById("github-auth-status");
                const introElement = dc.getElementById("github-auth-intro");
                const identityElement = dc.getElementById(
                    "github-auth-identity"
                );
                const errorElement = dc.getElementById("github-auth-error");
                const diagnosticsElement = dc.getElementById(
                    "github-auth-diagnostics"
                );
                const copyDiagnosticsButton = dc.getElementById(
                    "github-auth-copy-diagnostics"
                );

                if (
                    !modal ||
                    !statusElement ||
                    !introElement ||
                    !identityElement ||
                    !errorElement ||
                    !diagnosticsElement ||
                    !copyDiagnosticsButton
                ) {
                    throw new Error(
                        "[ADMIN]: Elementos do modal de autenticação do GitHub não encontrados."
                    );
                }

                const githubAuthModal = new BootstrapNative.Modal(modal);
                let currentGitHubUser = null;
                let refreshInFlight = null;

                /**
                 * Shows an authentication error in the GitHub modal and logs it.
                 * @param {Error|string} error
                 */
                const showAuthError = error => {
                    const message =
                        error instanceof Error ? error.message : String(error);
                    statusElement.textContent =
                        authMessage("github_auth_failed");
                    diagnosticsElement.textContent = message;
                    errorElement.hidden = false;
                    console.error("[ADMIN AUTH]:", error);
                };

                copyDiagnosticsButton.addEventListener("click", async () => {
                    const diagnostics = diagnosticsElement.textContent || "";
                    if (!diagnostics) return;
                    try {
                        await navigator.clipboard.writeText(diagnostics);
                    } catch (error) {
                        console.error(
                            "[ADMIN AUTH]: Não foi possível copiar o diagnóstico.",
                            error
                        );
                    }
                });

                /**
                 * Shows the GitHub identity of the authenticated user in the admin interface.
                 * @param {Object} user - GitHub user data.
                 */
                const renderAdminGitHubIdentity = user => {
                    if (!user || typeof user !== "object") return;
                    currentGitHubUser = user;

                    const profileURL =
                        user.profile_url || user.html_url || user.url || "";

                    const sideAvatar = dc.getElementById("admin-github-avatar");
                    const sideName = dc.getElementById("admin-github-name");
                    const sideLogin = dc.getElementById("admin-github-login");

                    if (sideAvatar) {
                        sideAvatar.dataset.src = user.avatar_url || "";
                        sideAvatar.alt = user.name || user.login || "GitHub";
                        if (user.avatar_url) lazyLoad.observe([sideAvatar]);
                    }
                    if (sideName)
                        sideName.textContent = user.name || user.login || "";
                    if (sideLogin)
                        sideLogin.textContent = user.login
                            ? `@${user.login}`
                            : "";

                    const sessAvatar = dc.getElementById(
                        "admin-session-avatar"
                    );
                    const sessName = dc.getElementById("admin-session-name");
                    const sessLogin = dc.getElementById("admin-session-login");
                    const sessId = dc.getElementById("admin-session-id");
                    const sessProfile = dc.getElementById(
                        "admin-session-profile"
                    );
                    const sessEmail = dc.getElementById("admin-session-email");

                    if (sessAvatar) {
                        sessAvatar.dataset.src = user.avatar_url || "";
                        sessAvatar.alt = user.name || user.login || "GitHub";
                        if (user.avatar_url) lazyLoad.observe([sessAvatar]);
                    }
                    if (sessName)
                        sessName.textContent = user.name || user.login || "";
                    if (sessLogin)
                        sessLogin.textContent = user.login
                            ? `@${user.login}`
                            : "";
                    if (sessId) sessId.textContent = String(user.id ?? "");
                    if (sessProfile) {
                        sessProfile.textContent = profileURL;
                        sessProfile.href = profileURL || "#";
                    }
                    if (sessEmail) sessEmail.textContent = user.email || "—";
                };

                /**
                 * Shows the scope, the date obtained and the expiry date of the stored session.
                 * @param {Object} storedAuth - Stored session data.
                 */
                const renderSessionDetails = storedAuth => {
                    const tokens = storedAuth?.tokens || {};
                    const scopeEl = dc.getElementById("admin-session-scope");
                    const obtainedEl = dc.getElementById(
                        "admin-session-obtained"
                    );
                    const expiresEl = dc.getElementById(
                        "admin-session-expires"
                    );
                    const statusBadge = dc.getElementById(
                        "admin-session-status-badge"
                    );
                    const navDot = dc.getElementById("admin-session-nav-dot");

                    if (scopeEl)
                        scopeEl.textContent = tokens.scope || "default";

                    const obtainedAt = Number(tokens.obtained_at);
                    const expiresIn = Number(tokens.expires_in);

                    if (obtainedEl) {
                        obtainedEl.textContent =
                            Number.isFinite(obtainedAt) && obtainedAt > 0
                                ? new Date(obtainedAt).toLocaleString(
                                      PolicyHandler.language
                                  )
                                : "—";
                    }

                    let dotClass = "is-ok";
                    let badgeClass = "badge-success";
                    let statusKey = "status_active";

                    if (
                        Number.isFinite(expiresIn) &&
                        expiresIn > 0 &&
                        Number.isFinite(obtainedAt) &&
                        obtainedAt > 0
                    ) {
                        const expiresAt = obtainedAt + expiresIn * 1000;
                        if (expiresEl) {
                            expiresEl.textContent = new Date(
                                expiresAt
                            ).toLocaleString(PolicyHandler.language);
                        }
                        const remaining = expiresAt - Date.now();
                        if (remaining <= 0) {
                            dotClass = "is-err";
                            badgeClass = "badge-danger";
                            statusKey = "status_expired";
                        } else if (remaining <= TOKEN_REFRESH_MARGIN_MS) {
                            dotClass = "is-warn";
                            badgeClass = "badge-warning";
                            statusKey = "status_expiring";
                        }
                    } else {
                        if (expiresEl)
                            expiresEl.textContent =
                                dashMessage("status_no_expiry") || "—";
                    }

                    if (statusBadge) {
                        statusBadge.className = `badge ${badgeClass}`;
                        statusBadge.textContent = dashMessage(statusKey);
                    }
                    if (navDot) {
                        navDot.className = `admin-status-dot ml-auto ${dotClass}`;
                    }
                };

                /**
                 * Fetches the authentication diagnostics and shows them in the panel.
                 * @return {Promise<void>}
                 */
                const loadSessionDiagnostics = async () => {
                    const diagPre = dc.getElementById(
                        "admin-session-diagnostics"
                    );
                    if (!diagPre) return;

                    try {
                        const response = await fetch(
                            "/admin-auth/diagnostics",
                            {
                                cache: "no-store",
                                credentials: "same-origin"
                            }
                        );
                        if (!response.ok)
                            throw new Error(`HTTP ${response.status}`);
                        const payload = await response.json();
                        const entries = Array.isArray(payload?.entries)
                            ? payload.entries
                            : [];

                        if (!entries.length) {
                            diagPre.textContent =
                                dashMessage("diagnostics_empty");
                            return;
                        }

                        diagPre.textContent = entries
                            .slice(-40)
                            .map(
                                entry =>
                                    `[${entry.time}] ${entry.stage} (${entry.status}): ${entry.details}`
                            )
                            .join("\n");
                    } catch {
                        diagPre.textContent = dashMessage("diagnostics_error");
                    }
                };

                /**
                 * Resets and shows the GitHub authentication modal.
                 * @param {string} [messageText] - Message to show.
                 * @description Also clears the current GitHub API instance.
                 */
                const openReauthModal = messageText => {
                    GitHubAPIInstance = null;
                    introElement.hidden = false;
                    identityElement.hidden = true;
                    if (messageText) {
                        statusElement.textContent = messageText;
                    }
                    githubAuthModal.show();
                };

                /**
                 * Requests the renewal of the session (POST /admin-auth/refresh).
                 * @return {Promise<Object|null>} Response payload.
                 * @throws {Error} When the renewal fails.
                 */
                const performTokenRefresh = async () => {
                    const response = await fetch("/admin-auth/refresh", {
                        method: "POST",
                        credentials: "same-origin",
                        cache: "no-store"
                    });

                    let payload = null;
                    try {
                        payload = await response.json();
                    } catch {
                        payload = null;
                    }

                    if (!response.ok || !payload?.ok) {
                        const err = new Error(
                            payload?.message || `HTTP ${response.status}`
                        );
                        err.reauthRequired = Boolean(
                            payload?.reauth_required || response.status === 401
                        );
                        throw err;
                    }

                    const updatedAuth = await DBMethods.read({
                        tbn: "github",
                        tbk: "user-github"
                    });

                    if (
                        !updatedAuth?.user ||
                        !updatedAuth?.tokens?.access_token
                    ) {
                        const err = new Error(
                            "Credenciais renovadas não encontradas no IndexedDB."
                        );
                        err.reauthRequired = true;
                        throw err;
                    }

                    GitHubAPIInstance = new GitHubAPI(
                        {
                            token: updatedAuth.tokens.access_token
                        },
                        SiteAnalytics
                    );
                    renderAdminGitHubIdentity(updatedAuth.user);
                    renderSessionDetails(updatedAuth);
                    return true;
                };

                const ensureValidGitHubSession = async (
                    forceRefresh = false
                ) => {
                    if (!DBMethods) return false;

                    /**
                     * Restores the session from IndexedDB and renders the administrator identity and details.
                     */
                    const run = async () => {
                        const storedAuth = await DBMethods.read({
                            tbn: "github",
                            tbk: "user-github"
                        });

                        const user = storedAuth?.user;
                        const tokens = storedAuth?.tokens;
                        const token = tokens?.access_token;

                        if (!user || !token) {
                            openReauthModal(authMessage("github_auth_failed"));
                            return false;
                        }

                        const obtainedAt = Number(tokens.obtained_at);
                        const expiresIn = Number(tokens.expires_in);
                        const isExpiring =
                            Number.isFinite(expiresIn) &&
                            expiresIn > 0 &&
                            Number.isFinite(obtainedAt) &&
                            obtainedAt > 0 &&
                            Date.now() >=
                                obtainedAt +
                                    expiresIn * 1000 -
                                    TOKEN_REFRESH_MARGIN_MS;

                        if (forceRefresh || isExpiring) {
                            if (!tokens.refresh_token) {
                                if (forceRefresh) {
                                    openReauthModal(
                                        dashMessage("reauth_needed")
                                    );
                                    return false;
                                }
                            } else {
                                try {
                                    return await performTokenRefresh();
                                } catch (error) {
                                    console.error(
                                        "[ADMIN AUTH REFRESH]:",
                                        error
                                    );
                                    if (error.reauthRequired) {
                                        openReauthModal(
                                            dashMessage("reauth_needed")
                                        );
                                    }
                                    return false;
                                }
                            }
                        }

                        if (!GitHubAPIInstance) {
                            const api = new GitHubAPI(
                                { token },
                                SiteAnalytics
                            );
                            try {
                                await api.GHInstance.getUser().getProfile();
                                GitHubAPIInstance = api;
                                renderAdminGitHubIdentity(user);
                                renderSessionDetails(storedAuth);
                            } catch (error) {
                                if (
                                    error?.response?.status === 401 &&
                                    tokens.refresh_token
                                ) {
                                    try {
                                        return await performTokenRefresh();
                                    } catch (refreshErr) {
                                        openReauthModal(
                                            dashMessage("reauth_needed")
                                        );
                                        return false;
                                    }
                                }
                                if (error?.response?.status === 401) {
                                    openReauthModal(
                                        dashMessage("reauth_needed")
                                    );
                                    return false;
                                }
                                throw error;
                            }
                        }

                        return Boolean(GitHubAPIInstance);
                    };

                    if (refreshInFlight) return refreshInFlight;

                    refreshInFlight = run().finally(() => {
                        refreshInFlight = null;
                    });
                    return refreshInFlight;
                };

                /**
                 * Reads the GitHub session from IndexedDB.
                 * @return {Promise<Object>} The stored session.
                 * @throws {Error} If IndexedDB is not available.
                 */
                const loadAdminGitHubAuth = async () => {
                    if (!DBMethods) {
                        throw new Error(
                            "IndexedDB indisponível. Não foi possível recuperar a autenticação."
                        );
                    }

                    const storedAuth = await DBMethods.read({
                        tbn: "github",
                        tbk: "user-github"
                    });

                    const user = storedAuth?.user;
                    const token = storedAuth?.tokens?.access_token;

                    if (!user || !token) {
                        GitHubAPIInstance = null;
                        introElement.hidden = false;
                        identityElement.hidden = true;
                        githubAuthModal.show();
                        return;
                    }

                    const ok = await ensureValidGitHubSession(false);
                    if (ok && currentGitHubUser) {
                        statusElement.textContent = authMessage(
                            "github_auth_authenticated",
                            currentGitHubUser.login || ""
                        );
                    }
                };

                statusElement.textContent = authMessage(
                    "github_auth_verifying"
                );

                try {
                    await loadAdminGitHubAuth();
                } catch (error) {
                    GitHubAPIInstance = null;
                    githubAuthModal.show();
                    showAuthError(error);
                }

                const sidebar = dc.getElementById("admin-sidebar");
                const sidebarToggle = dc.getElementById("admin-sidebar-toggle");
                const sidebarClose = dc.getElementById("admin-sidebar-close");
                const sidebarBackdrop = dc.getElementById(
                    "admin-sidebar-backdrop"
                );

                /**
                 * Opens or closes the admin sidebar and its backdrop.
                 * @param {boolean} open
                 */
                const setSidebarOpen = open => {
                    if (!sidebar) return;
                    sidebar.classList.toggle("is-open", open);
                    if (sidebarBackdrop) sidebarBackdrop.hidden = !open;
                    if (sidebarToggle)
                        sidebarToggle.setAttribute(
                            "aria-expanded",
                            String(open)
                        );
                };

                if (sidebarToggle) {
                    sidebarToggle.addEventListener("click", () => {
                        setSidebarOpen(!sidebar?.classList.contains("is-open"));
                    });
                }
                if (sidebarClose) {
                    sidebarClose.addEventListener("click", () =>
                        setSidebarOpen(false)
                    );
                }
                if (sidebarBackdrop) {
                    sidebarBackdrop.addEventListener("click", () =>
                        setSidebarOpen(false)
                    );
                }

                const views = {
                    posts: dc.getElementById("admin-view-posts"),
                    editor: dc.getElementById("admin-view-editor"),
                    footoodles: dc.getElementById("admin-view-footoodles"),
                    session: dc.getElementById("admin-view-session"),
                    credentials: dc.getElementById("admin-view-credentials"),
                    records: dc.getElementById("admin-view-records"),
                    devtools: dc.getElementById("admin-view-devtools")
                };


                const credentialsList = dc.getElementById(
                    "admin-credentials-list"
                );

                const credentialsCount = dc.getElementById(
                    "admin-credentials-count"
                );

                const credentialsEmpty = dc.getElementById(
                    "admin-credentials-empty"
                );

                const credentialsExportAllButton = dc.getElementById(
                    "admin-credentials-export-all"
                );

                const credentialsImportButton = dc.getElementById(
                    "admin-credentials-import"
                );

                const credentialsImportFile = dc.getElementById(
                    "admin-credentials-import-file"
                );
                /**
                 * Converts a base64url value to base64 with padding.
                 * @param {string} value
                 * @return {string}
                 */
                const base64UrlToBase64 = value => {
                    const base64 = value.replace(/-/g, "+").replace(/_/g, "/");

                    return base64.padEnd(Math.ceil(base64.length / 4) * 4, "=");
                };

                /**
                 * Formats a key in PEM format.
                 * @param {string} value - Base64url key data.
                 * @param {"public"|"private"} type
                 * @return {string}
                 */
                const formatPEM = (value, type) => {
                    const base64 = base64UrlToBase64(value);
                    const lines = base64.match(/.{1,64}/g) || [];

                    const label =
                        type === "public" ? "PUBLIC KEY" : "PRIVATE KEY";

                    return [
                        `-----BEGIN ${label}-----`,
                        ...lines,
                        `-----END ${label}-----`
                    ].join("\n");
                };

                /**
                 * Renders the list of JWT credentials and their count.
                 * @return {void}
                 */
                const renderCredentials = () => {
                    if (
                        !jwtManager ||
                        !credentialsList ||
                        !credentialsCount ||
                        !credentialsEmpty
                    ) {
                        return;
                    }

                    const credentials = jwtManager.getCredentials();

                    credentialsCount.textContent = String(credentials.length);

                    credentialsEmpty.hidden = credentials.length > 0;

                    if (credentialsExportAllButton) {
                        credentialsExportAllButton.disabled =
                            !jwtManager || credentials.length === 0;
                    }

                    credentialsList.innerHTML = credentials
                        .map(credential => {
                            const metadata = credential.metadata || {};

                            const tokens = Array.isArray(credential.tokens)
                                ? credential.tokens
                                : [];

                            const createdAt = metadata.createdAt
                                ? new Date(metadata.createdAt).toLocaleString()
                                : "—";

                            const credentialName =
                                metadata.name || "Credencial sem nome";

                            const credentialDescription =
                                metadata.description ||
                                "Sem descrição cadastrada.";

                            const tokenHTML = tokens.length
                                ? tokens
                                      .map(token => {
                                          const expiration = token.expiresAt
                                              ? new Date(
                                                    token.expiresAt * 1000
                                                ).toLocaleString()
                                              : "—";

                                          const tokenName =
                                              token.name || "JWT sem nome";

                                          const tokenDescription =
                                              token.description ||
                                              "Sem descrição cadastrada.";

                                          return `
                                        <div class="border-top mt-3 pt-3">

                                            <div class="d-flex align-items-start justify-content-between">
                                                <div class="mr-2">
                                                    <p class="font-weight-bold mb-1">
                                                        ${escHTML(tokenName)}
                                                    </p>

                                                    <p class="small text-muted mb-2">
                                                        ${escHTML(tokenDescription)}
                                                    </p>
                                                </div>

                                                <button
                                                    type="button"
                                                    class="btn btn-outline-secondary btn-sm rounded-0"
                                                    data-jwt-metadata="token"
                                                    data-jwt-kid="${escHTML(credential.kid)}"
                                                    data-jwt-jti="${escHTML(token.jti || "")}">
                                                    Editar
                                                </button>
                                            </div>

                                            <p class="small mb-1">
                                                <strong>Audience:</strong>
                                                ${escHTML(token.aud || "—")}
                                            </p>

                                            <p class="small mb-1">
                                                <strong>JTI:</strong>
                                                <code class="text-break">${escHTML(token.jti || "—")}</code>
                                            </p>

                                            <p class="small mb-2">
                                                <strong>Expiração:</strong>
                                                ${escHTML(expiration)}
                                            </p>

                                            <div class="d-flex flex-wrap">

                                                <button
                                                    type="button"
                                                    class="btn btn-outline-primary btn-sm rounded-0 mr-2 mb-2"
                                                    data-jwt-token-copy="${escHTML(token.jti || "")}"
                                                    data-jwt-kid="${escHTML(credential.kid)}">
                                                    Copiar JWT
                                                </button>

                                                <button
                                                    type="button"
                                                    class="btn btn-outline-secondary btn-sm rounded-0 mr-2 mb-2"
                                                    data-jwt-token-renew="${escHTML(token.jti || "")}"
                                                    data-jwt-kid="${escHTML(credential.kid)}">
                                                    Renovar JWT
                                                </button>

                                                <button
                                                    type="button"
                                                    class="btn btn-outline-danger btn-sm rounded-0 mb-2"
                                                    data-jwt-token-delete="${escHTML(token.jti || "")}"
                                                    data-jwt-kid="${escHTML(credential.kid)}">
                                                    Excluir JWT
                                                </button>

                                            </div>

                                        </div>
                                    `;
                                      })
                                      .join("")
                                : `
                                    <p class="small text-muted border-top mt-3 pt-3 mb-0">
                                        Nenhum JWT gerado para esta credencial.
                                    </p>
                                `;

                            return `
                <div class="col-12 col-lg-6 mb-3">
                    <article class="card rounded-0 border h-100">
                        <div class="card-body">

                            <div class="d-flex align-items-start justify-content-between mb-3">

                                <div class="mr-2">
                                    <h3 class="h5 mb-1">
                                        ${escHTML(credentialName)}
                                    </h3>

                                    <p class="small text-muted mb-0">
                                        ${escHTML(credentialDescription)}
                                    </p>
                                </div>

                                <button
                                    type="button"
                                    class="btn btn-outline-secondary btn-sm rounded-0"
                                    data-jwt-metadata="credential"
                                    data-jwt-kid="${escHTML(credential.kid)}">
                                    Editar
                                </button>

                            </div>

                            <p class="small text-muted mb-1">
                                Identificador
                            </p>

                            <p class="text-break">
                                <code>${escHTML(credential.kid)}</code>
                            </p>

                            <p class="small mb-1">
                                <strong>Emissor:</strong>
                                ${escHTML(metadata.issuer || "—")}
                            </p>

                            <p class="small mb-1">
                                <strong>Algoritmo:</strong>
                                ${escHTML(metadata.algorithm || "—")}
                            </p>

                            <p class="small mb-3">
                                <strong>Criação:</strong>
                                ${escHTML(createdAt)}
                            </p>

                            <div class="d-flex flex-wrap">

                                <button
                                    type="button"
                                    class="btn btn-info btn-sm rounded-0 mr-2 mb-2"
                                    data-jwt-create="${escHTML(credential.kid)}">
                                    Gerar JWT
                                </button>

                                <button
                                    type="button"
                                    class="btn btn-outline-primary btn-sm rounded-0 mr-2 mb-2"
                                    data-jwt-copy="public"
                                    data-jwt-kid="${escHTML(credential.kid)}">
                                    Copiar chave pública
                                </button>

                                <button
                                    type="button"
                                    class="btn btn-outline-primary btn-sm rounded-0 mr-2 mb-2"
                                    data-jwt-copy="private"
                                    data-jwt-kid="${escHTML(credential.kid)}">
                                    Copiar chave privada
                                </button>

                                <button
                                    type="button"
                                    class="btn btn-outline-secondary btn-sm rounded-0 mr-2 mb-2"
                                    data-jwt-copy="key"
                                    data-jwt-kid="${escHTML(credential.kid)}">
                                    Copiar key (K_)
                                </button>

                                <button
                                    type="button"
                                    class="btn btn-outline-secondary btn-sm rounded-0 mr-2 mb-2"
                                    data-jwt-export="${escHTML(credential.kid)}">
                                    Exportar JSON
                                </button>

                                <button
                                    type="button"
                                    class="btn btn-outline-danger btn-sm rounded-0 mb-2"
                                    data-jwt-delete="${escHTML(credential.kid)}">
                                    Excluir credencial
                                </button>

                            </div>

                            <div class="mt-3">

                                <p class="small font-weight-bold mb-2">
                                    JWTs desta credencial (${tokens.length})
                                </p>

                                ${tokenHTML}

                            </div>

                        </div>
                    </article>
                </div>
            `;
                        })
                        .join("");
                };

                renderCredentials();

                /**
                 * Shows an admin view by name. Unknown names fall back to "posts".
                 * @param {string} viewName
                 * @description The devtools and records views load their data when opened.
                 */
                const showAdminView = viewName => {
                    const target = views[viewName] ? viewName : "posts";

                    if (target === "devtools") {
                        loadDevTools();
                    }

                    if (target === "records") {
                        recordsManager.loadAll();
                    }
                    Object.entries(views).forEach(([key, section]) => {
                        if (section) section.hidden = key !== target;
                    });

                    const activeNavKey = target === "editor" ? "posts" : target;
                    dc.querySelectorAll("[data-admin-nav]").forEach(btn => {
                        const isMatch = btn.dataset.adminNav === activeNavKey;
                        btn.classList.toggle("active", isMatch);
                        btn.setAttribute("aria-selected", String(isMatch));
                    });

                    setSidebarOpen(false);

                    if (target === "session") {
                        DBMethods?.read({ tbn: "github", tbk: "user-github" })
                            .then(
                                stored => stored && renderSessionDetails(stored)
                            )
                            .catch(() => {});
                        loadSessionDiagnostics();
                    }
                };
                const devToolsRoot = views.devtools;

                /**
                 * Returns a translated devtools text, or the fallback text when the translation is missing.
                 * @param {string} key
                 * @param {string} fallback
                 * @return {string}
                 */
                const devToolsText = (key, fallback) => {
                    const value = i18n.getWord(
                        `admin_dashboard.devtools.${key}`
                    );
                    return value && value !== `admin_dashboard.devtools.${key}`
                        ? value
                        : fallback;
                };

                /**
                 * Builds the HTML of a devtools action button.
                 * @param {string} action
                 * @param {string} label
                 * @param {string} [attributes=""]
                 * @return {string}
                 */
                const devToolsButton = (action, label, attributes = "") => `
    <button
        type="button"
        class="btn btn-sm btn-outline-danger rounded-0 mt-2"
        data-devtools-action="${action}"
        ${attributes}>
        ${escHTML(label)}
    </button>
`;

                /**
                 * Builds the HTML of a devtools error message.
                 * @param {Error|string} error
                 * @return {string}
                 */
                const devToolsError = error => `
    <p class="text-danger mb-0">
        ${escHTML(error?.message || String(error))}
    </p>
`;

                const devToolsServiceWorkers = document.createElement("div");
                devToolsServiceWorkers.className = "col-12 mb-4";
                devToolsServiceWorkers.innerHTML = `
    <div class="card rounded-0 border">
        <div class="card-header bg-white py-2">
            <h3 class="h6 mb-0">Service Workers</h3>
        </div>
        <div class="card-body">
            <div id="admin-devtools-service-workers" class="small"></div>
        </div>
    </div>
`;

                devToolsRoot
                    .querySelector(".row")
                    ?.prepend(devToolsServiceWorkers);

                /**
                 * Renders the registered service workers in devtools.
                 * @param {Object} result - Result of DevTools.refresh().
                 */
                const renderServiceWorkers = result => {
                    const root = dc.getElementById(
                        "admin-devtools-service-workers"
                    );

                    if (!root) return;

                    if (!result.registrations.length) {
                        root.textContent = "Nenhum Service Worker registrado.";
                        return;
                    }

                    root.innerHTML = result.registrations
                        .map(
                            registration => `
        <article class="border-bottom pb-3 mb-3">
            <p class="font-weight-bold mb-1">
                ${escHTML(registration.scope)}
            </p>

            ${["active", "waiting", "installing"]
                .map(state => {
                    const worker = registration[state];

                    return worker
                        ? `
                    <div class="mb-1">
                        <strong>${state}:</strong>
                        ${escHTML(worker.state)}
                        <div class="text-muted text-break">
                            ${escHTML(worker.scriptURL)}
                        </div>
                    </div>
                `
                        : "";
                })
                .join("")}

            ${devToolsButton(
                "unregister-sw",
                "Desregistrar",
                `data-scope="${escHTML(registration.scope)}"`
            )}
        </article>
    `
                        )
                        .join("");
                };

                /**
                 * Renders the IndexedDB databases and their object stores in devtools.
                 * @param {Object} result
                 */
                const renderIndexedDB = result => {
                    const root = dc.getElementById("admin-devtools-indexeddb");

                    if (!root) return;

                    if (!result.databases.length) {
                        root.textContent = "Nenhum banco IndexedDB encontrado.";
                        return;
                    }

                    root.innerHTML = result.databases
                        .map(
                            database => `
        <article class="border-bottom pb-3 mb-3">
            <p class="font-weight-bold mb-1">
                ${escHTML(database.name)}
            </p>

            <p class="text-muted mb-1">
                Versão: ${escHTML(database.version ?? "—")}
            </p>

            ${
                database.isApplicationDatabase
                    ? `
                <p class="text-success mb-1">
                    Banco da aplicação
                </p>

                <strong>Object Stores:</strong>

                <ul class="mb-2">
                    ${(database.objectStores || [])
                        .map(
                            store => `
                        <li>${escHTML(store)}</li>
                    `
                        )
                        .join("")}
                </ul>

                ${devToolsButton(
                    "delete-db",
                    "Excluir banco",
                    `data-name="${escHTML(database.name)}" data-app-db="true"`
                )}
            `
                    : `
                ${devToolsButton(
                    "delete-db",
                    "Excluir banco",
                    `data-name="${escHTML(database.name)}"`
                )}
            `
            }
        </article>
    `
                        )
                        .join("");
                };

                /**
                 * Renders the Cache Storage entries in devtools.
                 * @param {Object} result
                 */
                const renderCaches = result => {
                    const root = dc.getElementById(
                        "admin-devtools-cache-storage"
                    );

                    if (!root) return;

                    if (!result.caches.length) {
                        root.textContent = "Nenhum cache encontrado.";
                        return;
                    }

                    root.innerHTML = result.caches
                        .map(
                            cache => `
        <article class="border-bottom pb-3 mb-3">
            <p class="font-weight-bold mb-1">
                ${escHTML(cache.name)}
            </p>

            <p class="text-muted mb-2">
                Entradas: ${cache.count}
            </p>

            <ul class="mb-2 pl-3">
                ${cache.entries
                    .map(
                        url => `
                    <li class="text-break">${escHTML(url)}</li>
                `
                    )
                    .join("")}
            </ul>

            ${devToolsButton(
                "delete-cache",
                "Excluir cache",
                `data-name="${escHTML(cache.name)}"`
            )}
        </article>
    `
                        )
                        .join("");
                };

                /**
                 * Renders the localStorage and sessionStorage areas in devtools.
                 * @param {Object} result
                 */
                const renderWebStorage = result => {
                    const root = dc.getElementById(
                        "admin-devtools-local-storage"
                    );

                    if (!root) return;

                    /**
                     * Builds the HTML section of one storage area.
                     * @param {string} name
                     * @param {Object} storage - Area data, including the record count.
                     * @return {string}
                     */
                    const renderArea = (name, storage) => `
        <section class="mb-4">
            <h4 class="h6">${name}</h4>

            <p class="text-muted mb-2">
                Registros: ${storage.count}
            </p>

            ${
                storage.entries.length
                    ? `
                ${storage.entries
                    .map(
                        entry => `
                    <div class="border-bottom py-2">
                        <strong class="text-break">
                            ${escHTML(entry.key)}
                        </strong>

                        <pre class="small bg-light border p-2 mt-1 mb-0 text-break">${escHTML(entry.value)}</pre>
                    </div>
                `
                    )
                    .join("")}
            `
                    : `
                <p class="text-muted">Nenhum registro.</p>
            `
            }

            ${devToolsButton(
                "clear-storage",
                `Limpar ${name}`,
                `data-type="${name}"`
            )}
        </section>
    `;

                    root.innerHTML =
                        renderArea("Local Storage", result.localStorage) +
                        renderArea("Session Storage", result.sessionStorage);
                };

                /**
                 * Renders the accessible cookies in devtools.
                 * @param {Object} result
                 */
                const renderCookies = result => {
                    const root = dc.getElementById("admin-devtools-cookies");

                    if (!root) return;

                    if (!result.cookies.length) {
                        root.textContent =
                            "Nenhum cookie acessível encontrado.";
                        return;
                    }

                    root.innerHTML = result.cookies
                        .map(
                            cookie => `
        <article class="border-bottom pb-3 mb-3">
            <strong>${escHTML(cookie.name)}</strong>

            <pre class="small bg-light border p-2 mt-1 text-break">${escHTML(cookie.value)}</pre>

            <p class="text-muted mb-1">
                Domínio: ${escHTML(cookie.domain || "—")}
            </p>

            <p class="text-muted mb-1">
                Caminho: ${escHTML(cookie.path || "—")}
            </p>

            <p class="text-muted mb-1">
                SameSite: ${escHTML(cookie.sameSite || "—")}
            </p>

            ${devToolsButton(
                "delete-cookie",
                "Excluir cookie",
                `data-name="${escHTML(cookie.name)}"
                 data-domain="${escHTML(cookie.domain || "")}"
                 data-path="${escHTML(cookie.path || "/")}"`
            )}
        </article>
    `
                        )
                        .join("");
                };

                let devToolsLoading = false;

                /**
                 * Refreshes and renders the devtools data.
                 * @return {Promise<void>}
                 * @description Concurrent calls are ignored while a refresh is in progress.
                 */
                const loadDevTools = async () => {
                    if (devToolsLoading || !devToolsRoot) return;

                    devToolsLoading = true;

                    try {
                        const result = await DevTools.refresh();

                        const renderers = {
                            serviceWorkers: renderServiceWorkers,
                            indexedDB: renderIndexedDB,
                            caches: renderCaches,
                            webStorage: renderWebStorage,
                            cookies: renderCookies
                        };

                        Object.entries(renderers).forEach(([name, render]) => {
                            const error = result.errors[name];

                            if (error) {
                                const target = {
                                    serviceWorkers:
                                        "admin-devtools-service-workers",
                                    indexedDB: "admin-devtools-indexeddb",
                                    caches: "admin-devtools-cache-storage",
                                    webStorage: "admin-devtools-local-storage",
                                    cookies: "admin-devtools-cookies"
                                }[name];

                                const element = dc.getElementById(target);

                                if (element) {
                                    element.innerHTML = devToolsError(
                                        error.message
                                    );
                                }

                                return;
                            }

                            if (result.data[name]) {
                                render(result.data[name]);
                            }
                        });
                    } catch (error) {
                        console.error("[DEVTOOLS]:", error);
                    } finally {
                        devToolsLoading = false;
                    }
                };

                const devToolsConfirmModalElement = dc.getElementById(
                    "admin-modal-devtools-confirm"
                );

                const devToolsConfirmModal = devToolsConfirmModalElement
                    ? new BootstrapNative.Modal(devToolsConfirmModalElement)
                    : null;

                const devToolsConfirmTitle = dc.getElementById(
                    "admin-modal-devtools-confirm-title"
                );

                const devToolsConfirmMessage = dc.getElementById(
                    "admin-modal-devtools-confirm-message"
                );

                const devToolsConfirmTarget = dc.getElementById(
                    "admin-modal-devtools-confirm-target"
                );

                const devToolsConfirmWarning = dc.getElementById(
                    "admin-modal-devtools-confirm-warning"
                );

                const devToolsConfirmError = dc.getElementById(
                    "admin-modal-devtools-confirm-error"
                );

                const devToolsConfirmSubmitButton = dc.getElementById(
                    "admin-devtools-confirm-submit"
                );

                const devToolsConfirmCancelButton = dc.getElementById(
                    "admin-devtools-confirm-cancel"
                );

                let pendingDevToolsOperation = null;

                /**
                 * Opens the Bootstrap confirmation modal for a DevTools destructive operation.
                 * @param {Object} operation
                 */
                const openDevToolsConfirmModal = operation => {
                    if (!devToolsConfirmModal) return;

                    pendingDevToolsOperation = operation;

                    if (devToolsConfirmTitle) {
                        devToolsConfirmTitle.textContent =
                            operation.title || "Confirmar exclusão";
                    }

                    if (devToolsConfirmMessage) {
                        devToolsConfirmMessage.textContent =
                            operation.message ||
                            "Deseja realmente executar esta ação?";
                    }

                    if (devToolsConfirmTarget) {
                        const targetText = operation.target || "";
                        devToolsConfirmTarget.textContent = targetText;
                        devToolsConfirmTarget.hidden = !targetText;
                    }

                    if (devToolsConfirmWarning) {
                        devToolsConfirmWarning.hidden = !operation.isAppDb;
                    }

                    if (devToolsConfirmError) {
                        devToolsConfirmError.textContent = "";
                        devToolsConfirmError.hidden = true;
                    }

                    if (devToolsConfirmSubmitButton) {
                        devToolsConfirmSubmitButton.textContent =
                            operation.submitLabel || "Excluir";
                        devToolsConfirmSubmitButton.disabled = false;
                    }

                    if (devToolsConfirmCancelButton) {
                        devToolsConfirmCancelButton.disabled = false;
                    }

                    devToolsConfirmModal.show();
                };

                if (devToolsConfirmModalElement) {
                    devToolsConfirmModalElement.addEventListener(
                        "hidden.bs.modal",
                        () => {
                            if (
                                devToolsConfirmSubmitButton &&
                                !devToolsConfirmSubmitButton.disabled
                            ) {
                                pendingDevToolsOperation = null;
                            }
                        }
                    );
                }

                if (devToolsConfirmSubmitButton) {
                    devToolsConfirmSubmitButton.addEventListener(
                        "click",
                        async () => {
                            if (!pendingDevToolsOperation) return;

                            const operation = pendingDevToolsOperation;

                            devToolsConfirmSubmitButton.disabled = true;
                            if (devToolsConfirmCancelButton) {
                                devToolsConfirmCancelButton.disabled = true;
                            }
                            if (devToolsConfirmError) {
                                devToolsConfirmError.textContent = "";
                                devToolsConfirmError.hidden = true;
                            }

                            try {
                                switch (operation.action) {
                                    case "unregister-sw":
                                        await DevTools.unregisterServiceWorker(
                                            operation.scope
                                        );
                                        break;

                                    case "delete-db":
                                        await DevTools.deleteIndexedDB(
                                            operation.name
                                        );
                                        break;

                                    case "delete-cache":
                                        await DevTools.deleteCache(
                                            operation.name
                                        );
                                        break;

                                    case "clear-storage":
                                        DevTools.clearStorage(operation.type);
                                        break;

                                    case "delete-cookie":
                                        await DevTools.deleteCookie({
                                            name: operation.name,
                                            ...(operation.domain
                                                ? { domain: operation.domain }
                                                : {}),
                                            ...(operation.path
                                                ? { path: operation.path }
                                                : {})
                                        });
                                        break;

                                    default:
                                        return;
                                }

                                pendingDevToolsOperation = null;
                                devToolsConfirmModal?.hide();

                                if (
                                    operation.action === "delete-db" &&
                                    operation.isAppDb
                                ) {
                                    wd.location.reload();
                                    return;
                                }

                                await loadDevTools();
                            } catch (error) {
                                console.error(
                                    "[DEVTOOLS]: Operation failed.",
                                    error
                                );

                                if (devToolsConfirmError) {
                                    devToolsConfirmError.textContent =
                                        error?.message || String(error);
                                    devToolsConfirmError.hidden = false;
                                }
                            } finally {
                                devToolsConfirmSubmitButton.disabled = false;
                                if (devToolsConfirmCancelButton) {
                                    devToolsConfirmCancelButton.disabled = false;
                                }
                            }
                        }
                    );
                }

                devToolsRoot.addEventListener("click", event => {
                    const button = event.target.closest(
                        "[data-devtools-action]"
                    );

                    if (!button) return;

                    const action = button.dataset.devtoolsAction;

                    switch (action) {
                        case "unregister-sw": {
                            const scope = button.dataset.scope;

                            openDevToolsConfirmModal({
                                action,
                                scope,
                                title: "Desregistrar Service Worker",
                                message:
                                    "Deseja desregistrar este Service Worker?",
                                target: scope,
                                submitLabel: "Desregistrar"
                            });
                            break;
                        }

                        case "delete-db": {
                            const name = button.dataset.name;
                            const isAppDb =
                                button.dataset.appDb === "true" ||
                                name === settings.database.name;

                            openDevToolsConfirmModal({
                                action,
                                name,
                                isAppDb,
                                title: isAppDb
                                    ? "Excluir banco principal da aplicação"
                                    : "Excluir banco IndexedDB",
                                message: isAppDb
                                    ? "Deseja realmente excluir o banco de dados principal da aplicação?"
                                    : "Deseja realmente excluir este banco IndexedDB?",
                                target: name,
                                submitLabel: "Excluir banco"
                            });
                            break;
                        }

                        case "delete-cache": {
                            const name = button.dataset.name;

                            openDevToolsConfirmModal({
                                action,
                                name,
                                title: "Excluir cache",
                                message: "Deseja realmente excluir este cache?",
                                target: name,
                                submitLabel: "Excluir cache"
                            });
                            break;
                        }

                        case "clear-storage": {
                            const type = button.dataset.type;

                            openDevToolsConfirmModal({
                                action,
                                type,
                                title: "Limpar armazenamento",
                                message: `Deseja realmente limpar todo o conteúdo de ${type}?`,
                                target: type,
                                submitLabel: "Limpar"
                            });
                            break;
                        }

                        case "delete-cookie": {
                            const name = button.dataset.name;
                            const domain = button.dataset.domain;
                            const path = button.dataset.path;

                            openDevToolsConfirmModal({
                                action,
                                name,
                                domain,
                                path,
                                title: "Excluir cookie",
                                message:
                                    "Deseja realmente excluir este cookie?",
                                target: name,
                                submitLabel: "Excluir cookie"
                            });
                            break;
                        }

                        default:
                            return;
                    }
                });

                window.__adminShowView = showAdminView;

                dc.querySelectorAll("[data-admin-nav]").forEach(btn => {
                    btn.addEventListener("click", () => {
                        showAdminView(btn.dataset.adminNav);
                    });
                });


                const credentialsNewButton = dc.getElementById(
                    "admin-credentials-new"
                );

                const credentialsFeedback = dc.getElementById(
                    "admin-credentials-feedback"
                );

                /**
                 * Shows a feedback message in the credentials panel.
                 * @param {string} message
                 * @param {string} [type="success"] - Bootstrap alert type.
                 */
                const showCredentialsFeedback = (message, type = "success") => {
                    if (!credentialsFeedback) return;

                    credentialsFeedback.className = `alert alert-${type} rounded-0 small mb-3`;

                    credentialsFeedback.textContent = message;
                    credentialsFeedback.hidden = false;
                };

                const credentialCreateModalElement = dc.getElementById(
                    "admin-modal-credential-create"
                );

                const tokenCreateModalElement = dc.getElementById(
                    "admin-modal-token-create"
                );

                const metadataModalElement = dc.getElementById(
                    "admin-modal-metadata"
                );

                const confirmModalElement = dc.getElementById(
                    "admin-modal-confirm"
                );

                const credentialCreateModal = credentialCreateModalElement
                    ? new BootstrapNative.Modal(credentialCreateModalElement)
                    : null;

                const tokenCreateModal = tokenCreateModalElement
                    ? new BootstrapNative.Modal(tokenCreateModalElement)
                    : null;

                const metadataModal = metadataModalElement
                    ? new BootstrapNative.Modal(metadataModalElement)
                    : null;

                const confirmModal = confirmModalElement
                    ? new BootstrapNative.Modal(confirmModalElement)
                    : null;

                const credentialCreateForm = dc.getElementById(
                    "admin-form-credential-create"
                );

                const tokenCreateForm = dc.getElementById(
                    "admin-form-token-create"
                );

                const metadataForm = dc.getElementById("admin-form-metadata");

                const tokenAudienceSelect = dc.getElementById(
                    "admin-token-audience"
                );

                const confirmSubmitButton = dc.getElementById(
                    "admin-confirm-submit"
                );

                /**
                 * Fills the audience selector with the services configured in the settings.
                 */
                const fillTokenAudiences = () => {
                    if (!tokenAudienceSelect) return;
                    const services = settings.jwt?.services || [];

                    tokenAudienceSelect.innerHTML = "";

                    const placeholder = dc.createElement("option");
                    placeholder.value = "";
                    placeholder.textContent = "Selecione um serviço";
                    placeholder.disabled = true;
                    placeholder.selected = true;

                    tokenAudienceSelect.appendChild(placeholder);

                    services.forEach(value => {
                        if (typeof value !== "string" || !value.trim()) {
                            return;
                        }

                        const option = dc.createElement("option");
                        option.value = value;
                        option.textContent = value;

                        tokenAudienceSelect.appendChild(option);
                    });

                    tokenAudienceSelect.disabled =
                        tokenAudienceSelect.options.length <= 1;
                };

                /**
                 * Opens the modal to create a credential.
                 */
                const openCredentialCreateModal = () => {
                    if (!credentialCreateModal || !credentialCreateForm) {
                        showCredentialsFeedback(
                            "O formulário de criação de credencial não foi encontrado.",
                            "danger"
                        );
                        return;
                    }

                    credentialCreateForm.reset();
                    credentialCreateModal.show();
                };

                /**
                 * Opens the modal to create a JWT for a credential.
                 * @param {string} kid - Credential identifier.
                 */
                const openTokenCreateModal = kid => {
                    if (!tokenCreateModal || !tokenCreateForm) {
                        showCredentialsFeedback(
                            "O formulário de criação de JWT não foi encontrado.",
                            "danger"
                        );
                        return;
                    }

                    tokenCreateForm.reset();

                    dc.getElementById("admin-token-kid").value = kid;

                    fillTokenAudiences();

                    const expiresSelect = dc.getElementById(
                        "admin-token-expires"
                    );

                    if (expiresSelect) {
                        expiresSelect.value = "8h";
                    }

                    tokenCreateModal.show();
                };

                const openMetadataModal = ({
                    type,
                    kid,
                    jti = "",
                    name = "",
                    description = ""
                }) => {
                    if (!metadataModal || !metadataForm) {
                        showCredentialsFeedback(
                            "O formulário de edição não foi encontrado.",
                            "danger"
                        );
                        return;
                    }

                    metadataForm.reset();

                    dc.getElementById("admin-metadata-type").value = type;
                    dc.getElementById("admin-metadata-kid").value = kid;
                    dc.getElementById("admin-metadata-jti").value = jti;
                    dc.getElementById("admin-metadata-name").value = name;
                    dc.getElementById("admin-metadata-description").value =
                        description;

                    const title = dc.getElementById(
                        "admin-modal-metadata-title"
                    );

                    if (title) {
                        title.textContent =
                            type === "credential"
                                ? "Editar credencial"
                                : "Editar identificação do JWT";
                    }

                    metadataModal.show();
                };

                let pendingCredentialOperation = null;

                /**
                 * Opens the confirmation modal for a deletion.
                 * @param {Object} options
                 * @param {string} options.type - Kind of item to delete.
                 * @param {string} options.kid - Credential identifier.
                 * @param {string} [options.jti=""] - Token identifier, when applicable.
                 * @param {string} options.message - Message shown to the user.
                 */
                const openConfirmModal = ({ type, kid, jti = "", message }) => {
                    if (!confirmModal) {
                        showCredentialsFeedback(
                            "O modal de confirmação não foi encontrado.",
                            "danger"
                        );
                        return;
                    }

                    pendingCredentialOperation = {
                        type,
                        kid,
                        jti
                    };

                    dc.getElementById("admin-confirm-type").value = type;
                    dc.getElementById("admin-confirm-kid").value = kid;
                    dc.getElementById("admin-confirm-jti").value = jti;

                    const messageElement = dc.getElementById(
                        "admin-modal-confirm-message"
                    );

                    if (messageElement) {
                        messageElement.textContent = message;
                    }

                    const title = dc.getElementById(
                        "admin-modal-confirm-title"
                    );

                    if (title) {
                        title.textContent =
                            type === "renew"
                                ? "Confirmar renovação"
                                : "Confirmar exclusão";
                    }

                    if (confirmSubmitButton) {
                        confirmSubmitButton.textContent =
                            type === "renew" ? "Renovar JWT" : "Excluir";
                        confirmSubmitButton.classList.toggle(
                            "btn-danger",
                            type !== "renew"
                        );
                        confirmSubmitButton.classList.toggle(
                            "btn-info",
                            type === "renew"
                        );
                    }

                    confirmModal.show();
                };

                /**
                 * Returns a credential by its identifier.
                 * @param {string} kid
                 * @return {Object|undefined}
                 */
                const getCredentialByKid = kid => {
                    return jwtManager
                        ?.getCredentials()
                        .find(item => item.kid === kid);
                };

                /**
                 * Triggers a JSON file download in the browser.
                 * @param {string} filename
                 * @param {*} data
                 */
                const downloadJSONFile = (filename, data) => {
                    const json = JSON.stringify(data, null, 4);
                    const blob = new Blob([json], {
                        type: "application/json;charset=utf-8"
                    });
                    const url = URL.createObjectURL(blob);
                    const link = dc.createElement("a");

                    link.href = url;
                    link.download = filename;
                    link.hidden = true;
                    dc.body.appendChild(link);
                    link.click();
                    link.remove();

                    setTimeout(() => URL.revokeObjectURL(url), 1000);
                };

                if (credentialsNewButton) {
                    credentialsNewButton.disabled = !jwtManager;

                    credentialsNewButton.addEventListener("click", () => {
                        if (!jwtManager) return;

                        openCredentialCreateModal();
                    });
                }

                if (credentialsExportAllButton) {
                    credentialsExportAllButton.disabled =
                        !jwtManager ||
                        jwtManager.getCredentials().length === 0;

                    credentialsExportAllButton.addEventListener("click", () => {
                        if (!jwtManager) return;

                        try {
                            const payload = jwtManager.exportCredentials();

                            if (!payload.credentials.length) {
                                showCredentialsFeedback(
                                    "Nenhuma credencial cadastrada para exportar.",
                                    "warning"
                                );
                                return;
                            }

                            const dateStamp = new Date()
                                .toISOString()
                                .slice(0, 10);

                            downloadJSONFile(
                                `subversivo58-credenciais-${dateStamp}.json`,
                                payload
                            );

                            showCredentialsFeedback(
                                `Exportação concluída: ${payload.credentials.length} credencial(is) salva(s) em JSON.`
                            );
                        } catch (error) {
                            console.error(
                                "[JWT]: Não foi possível exportar as credenciais.",
                                error
                            );

                            showCredentialsFeedback(
                                error?.message ||
                                    "Não foi possível exportar as credenciais.",
                                "danger"
                            );
                        }
                    });
                }

                if (credentialsImportButton && credentialsImportFile) {
                    credentialsImportButton.disabled = !jwtManager;

                    credentialsImportButton.addEventListener("click", () => {
                        if (!jwtManager) return;

                        credentialsImportFile.value = "";
                        credentialsImportFile.click();
                    });

                    credentialsImportFile.addEventListener(
                        "change",
                        async () => {
                            const file = credentialsImportFile.files?.[0];
                            credentialsImportFile.value = "";

                            if (!file || !jwtManager) return;

                            credentialsImportButton.disabled = true;

                            try {
                                const content = await file.text();
                                const summary =
                                    await jwtManager.importCredentials(content);

                                renderCredentials();

                                const details =
                                    summary.overwritten > 0
                                        ? ` (${summary.overwritten} sobrescrita(s))`
                                        : "";

                                showCredentialsFeedback(
                                    `Importação concluída: ${summary.imported} credencial(is) importada(s)${details}.`
                                );
                            } catch (error) {
                                console.error(
                                    "[JWT]: Não foi possível importar as credenciais.",
                                    error
                                );

                                showCredentialsFeedback(
                                    error?.message ||
                                        "Não foi possível importar o arquivo de credenciais.",
                                    "danger"
                                );
                            } finally {
                                credentialsImportButton.disabled = false;
                            }
                        }
                    );
                }


                if (credentialCreateForm) {
                    credentialCreateForm.addEventListener(
                        "submit",
                        async event => {
                            event.preventDefault();

                            if (!jwtManager) return;

                            const submitButton = dc.getElementById(
                                "admin-credential-create-submit"
                            );

                            const name = dc
                                .getElementById("admin-credential-name")
                                .value.trim();

                            const description = dc
                                .getElementById("admin-credential-description")
                                .value.trim();

                            if (!name || !description) {
                                showCredentialsFeedback(
                                    "Informe o nome e a descrição da credencial.",
                                    "danger"
                                );
                                return;
                            }

                            if (submitButton) submitButton.disabled = true;

                            try {
                                await jwtManager.createCredential({
                                    name,
                                    description
                                });

                                credentialCreateModal?.hide();

                                renderCredentials();

                                showCredentialsFeedback(
                                    "Credencial criada com sucesso."
                                );
                            } catch (error) {
                                console.error(
                                    "[JWT]: Não foi possível criar a credencial.",
                                    error
                                );

                                showCredentialsFeedback(
                                    error?.message || String(error),
                                    "danger"
                                );
                            } finally {
                                if (submitButton) {
                                    submitButton.disabled = false;
                                }
                            }
                        }
                    );
                }


                if (tokenCreateForm) {
                    tokenCreateForm.addEventListener("submit", async event => {
                        event.preventDefault();

                        if (!jwtManager) return;

                        const submitButton = dc.getElementById(
                            "admin-token-create-submit"
                        );

                        const kid = dc.getElementById("admin-token-kid").value;

                        const name = dc
                            .getElementById("admin-token-name")
                            .value.trim();

                        const description = dc
                            .getElementById("admin-token-description")
                            .value.trim();

                        const aud = tokenAudienceSelect?.value || "";

                        const expiresIn = dc.getElementById(
                            "admin-token-expires"
                        ).value;

                        const services = settings.jwt?.services || [];

                        if (!name || !description || !aud) {
                            showCredentialsFeedback(
                                "Preencha todos os campos para gerar o JWT.",
                                "danger"
                            );
                            return;
                        }

                        if (!services.includes(aud)) {
                            showCredentialsFeedback(
                                "O serviço selecionado não está configurado.",
                                "danger"
                            );
                            return;
                        }

                        if (!["8h", "6m", "1y"].includes(expiresIn)) {
                            showCredentialsFeedback(
                                "A validade selecionada é inválida.",
                                "danger"
                            );
                            return;
                        }

                        if (submitButton) submitButton.disabled = true;

                        try {
                            await jwtManager.createToken({
                                kid,
                                name,
                                description,
                                aud,
                                expiresIn
                            });

                            tokenCreateModal?.hide();

                            renderCredentials();

                            showCredentialsFeedback("JWT criado com sucesso.");
                        } catch (error) {
                            console.error(
                                "[JWT]: Não foi possível gerar o JWT.",
                                error
                            );

                            showCredentialsFeedback(
                                error?.message || String(error),
                                "danger"
                            );
                        } finally {
                            if (submitButton) {
                                submitButton.disabled = false;
                            }
                        }
                    });
                }

                // --------------------------------------------------
                // EDITAR METADADOS
                // --------------------------------------------------

                if (metadataForm) {
                    metadataForm.addEventListener("submit", async event => {
                        event.preventDefault();

                        if (!jwtManager) return;

                        const submitButton = dc.getElementById(
                            "admin-metadata-submit"
                        );

                        const type = dc.getElementById(
                            "admin-metadata-type"
                        ).value;

                        const kid =
                            dc.getElementById("admin-metadata-kid").value;

                        const jti =
                            dc.getElementById("admin-metadata-jti").value;

                        const name = dc
                            .getElementById("admin-metadata-name")
                            .value.trim();

                        const description = dc
                            .getElementById("admin-metadata-description")
                            .value.trim();

                        if (!name || !description) {
                            showCredentialsFeedback(
                                "Informe o nome e a descrição.",
                                "danger"
                            );
                            return;
                        }

                        if (submitButton) submitButton.disabled = true;

                        try {
                            if (type === "credential") {
                                await jwtManager.updateCredentialMetadata({
                                    kid,
                                    name,
                                    description
                                });
                            } else if (type === "token") {
                                await jwtManager.updateTokenMetadata({
                                    kid,
                                    jti,
                                    name,
                                    description
                                });
                            } else {
                                throw new Error("Tipo de metadado inválido.");
                            }

                            metadataModal?.hide();

                            renderCredentials();

                            showCredentialsFeedback(
                                "Identificação atualizada com sucesso."
                            );
                        } catch (error) {
                            console.error(
                                "[JWT]: Não foi possível atualizar os metadados.",
                                error
                            );

                            showCredentialsFeedback(
                                error?.message || String(error),
                                "danger"
                            );
                        } finally {
                            if (submitButton) {
                                submitButton.disabled = false;
                            }
                        }
                    });
                }


                if (confirmSubmitButton) {
                    confirmSubmitButton.addEventListener("click", async () => {
                        if (!jwtManager || !pendingCredentialOperation) {
                            return;
                        }

                        const operation = pendingCredentialOperation;

                        confirmSubmitButton.disabled = true;

                        try {
                            switch (operation.type) {
                                case "token-delete":
                                    await jwtManager.deleteToken({
                                        kid: operation.kid,
                                        jti: operation.jti
                                    });

                                    showCredentialsFeedback(
                                        "JWT excluído com sucesso."
                                    );
                                    break;

                                case "credential-delete":
                                    await jwtManager.deleteCredential(
                                        operation.kid
                                    );

                                    showCredentialsFeedback(
                                        "Credencial e todos os seus JWTs foram excluídos."
                                    );
                                    break;

                                case "renew":
                                    await jwtManager.refresh({
                                        kid: operation.kid,
                                        jti: operation.jti
                                    });

                                    showCredentialsFeedback(
                                        "JWT renovado com sucesso."
                                    );
                                    break;

                                default:
                                    throw new Error(
                                        "Operação de credencial desconhecida."
                                    );
                            }

                            confirmModal?.hide();
                            pendingCredentialOperation = null;

                            renderCredentials();
                        } catch (error) {
                            console.error(
                                "[JWT]: Não foi possível concluir a operação.",
                                error
                            );

                            showCredentialsFeedback(
                                error?.message || String(error),
                                "danger"
                            );
                        } finally {
                            confirmSubmitButton.disabled = false;
                        }
                    });
                }


                if (credentialsList) {
                    credentialsList.addEventListener("click", async event => {
                        const button = event.target.closest(
                            [
                                "[data-jwt-copy]",
                                "[data-jwt-export]",
                                "[data-jwt-delete]",
                                "[data-jwt-create]",
                                "[data-jwt-token-copy]",
                                "[data-jwt-token-renew]",
                                "[data-jwt-token-delete]",
                                "[data-jwt-metadata]"
                            ].join(", ")
                        );

                        if (!button || !jwtManager) return;

                        const kid =
                            button.dataset.jwtKid ||
                            button.dataset.jwtExport ||
                            button.dataset.jwtDelete ||
                            button.dataset.jwtCreate;

                        const credential = getCredentialByKid(kid);

                        if (!credential) {
                            showCredentialsFeedback(
                                "Credencial não encontrada.",
                                "danger"
                            );
                            return;
                        }


                        if (button.dataset.jwtCreate) {
                            openTokenCreateModal(kid);
                            return;
                        }

                        // ------------------------------------------
                        // EDITAR METADADOS
                        // ------------------------------------------

                        if (button.dataset.jwtMetadata) {
                            const type = button.dataset.jwtMetadata;

                            if (type === "credential") {
                                openMetadataModal({
                                    type,
                                    kid,
                                    name: credential.metadata?.name || "",
                                    description:
                                        credential.metadata?.description || ""
                                });

                                return;
                            }

                            if (type === "token") {
                                const jti = button.dataset.jwtJti;

                                const tokenRecord = credential.tokens.find(
                                    item => item.jti === jti
                                );

                                if (!tokenRecord) {
                                    showCredentialsFeedback(
                                        "JWT não encontrado.",
                                        "danger"
                                    );
                                    return;
                                }

                                openMetadataModal({
                                    type,
                                    kid,
                                    jti,
                                    name: tokenRecord.name || "",
                                    description: tokenRecord.description || ""
                                });

                                return;
                            }
                        }

                        // ------------------------------------------
                        // EXCLUIR JWT INDIVIDUAL
                        // ------------------------------------------

                        if (button.dataset.jwtTokenDelete) {
                            const jti = button.dataset.jwtTokenDelete;

                            openConfirmModal({
                                type: "token-delete",
                                kid,
                                jti,
                                message:
                                    "Deseja realmente excluir somente este JWT? A credencial e os demais tokens serão mantidos."
                            });

                            return;
                        }

                        // ------------------------------------------
                        // RENOVAR JWT
                        // ------------------------------------------

                        if (button.dataset.jwtTokenRenew) {
                            const jti = button.dataset.jwtTokenRenew;

                            openConfirmModal({
                                type: "renew",
                                kid,
                                jti,
                                message:
                                    "Deseja renovar este JWT? O token será substituído por uma nova emissão."
                            });

                            return;
                        }

                        // ------------------------------------------
                        // COPIAR JWT
                        // ------------------------------------------

                        if (button.dataset.jwtTokenCopy) {
                            const jti = button.dataset.jwtTokenCopy;

                            const tokenRecord = credential.tokens.find(
                                item => item.jti === jti
                            );

                            if (!tokenRecord?.token) {
                                showCredentialsFeedback(
                                    "JWT não encontrado.",
                                    "danger"
                                );
                                return;
                            }

                            try {
                                await navigator.clipboard.writeText(
                                    tokenRecord.token
                                );

                                showCredentialsFeedback(
                                    "JWT copiado para a área de transferência."
                                );
                            } catch (error) {
                                console.error(
                                    "[JWT]: Não foi possível copiar o JWT.",
                                    error
                                );

                                showCredentialsFeedback(
                                    error?.message ||
                                        "Não foi possível copiar o JWT.",
                                    "danger"
                                );
                            }

                            return;
                        }


                        if (button.dataset.jwtCopy) {
                            const type = button.dataset.jwtCopy;
                            let value;

                            try {
                                switch (type) {
                                    case "public":
                                        value = formatPEM(
                                            credential.keyPair.publicKey.value,
                                            "public"
                                        );
                                        break;

                                    case "private":
                                        value = formatPEM(
                                            credential.keyPair.privateKey.value,
                                            "private"
                                        );
                                        break;

                                    case "key":
                                        value = `K_${kid}`;
                                        break;

                                    default:
                                        throw new Error(
                                            "Tipo de cópia inválido."
                                        );
                                }

                                await navigator.clipboard.writeText(value);

                                showCredentialsFeedback(
                                    "Conteúdo copiado para a área de transferência."
                                );
                            } catch (error) {
                                console.error(
                                    "[JWT]: Não foi possível copiar o conteúdo.",
                                    error
                                );

                                showCredentialsFeedback(
                                    error?.message ||
                                        "Não foi possível copiar para a área de transferência.",
                                    "danger"
                                );
                            }

                            return;
                        }


                        if (button.dataset.jwtExport) {
                            try {
                                const exported =
                                    jwtManager.exportCredential(kid);

                                downloadJSONFile(
                                    `subversivo58-credencial-K_${kid}.json`,
                                    exported
                                );

                                showCredentialsFeedback(
                                    "Credencial exportada em JSON."
                                );
                            } catch (error) {
                                console.error(
                                    "[JWT]: Não foi possível exportar a credencial.",
                                    error
                                );

                                showCredentialsFeedback(
                                    error?.message ||
                                        "Não foi possível exportar a credencial.",
                                    "danger"
                                );
                            }

                            return;
                        }


                        if (button.dataset.jwtDelete) {
                            openConfirmModal({
                                type: "credential-delete",
                                kid,
                                message:
                                    "Deseja excluir esta credencial? O par de chaves e todos os JWTs associados serão removidos do armazenamento local."
                            });
                        }
                    });
                }

                const mobileNewPost = dc.getElementById(
                    "admin-mobile-new-post"
                );
                if (mobileNewPost) {
                    mobileNewPost.addEventListener("click", () => {
                        dc.getElementById("admin-new-post")?.click();
                    });
                }

                const sessionRefreshBtn = dc.getElementById(
                    "admin-session-refresh"
                );
                const sessionRefreshStatus = dc.getElementById(
                    "admin-session-refresh-status"
                );
                if (sessionRefreshBtn) {
                    sessionRefreshBtn.addEventListener("click", async () => {
                        sessionRefreshBtn.disabled = true;
                        if (sessionRefreshStatus) {
                            sessionRefreshStatus.hidden = false;
                            sessionRefreshStatus.className =
                                "small mt-2 mb-0 text-muted";
                            sessionRefreshStatus.textContent =
                                dashMessage("refreshing");
                        }

                        const ok = await ensureValidGitHubSession(true);
                        sessionRefreshBtn.disabled = false;

                        if (sessionRefreshStatus) {
                            sessionRefreshStatus.hidden = false;
                            sessionRefreshStatus.className = `small mt-2 mb-0 ${ok ? "text-success" : "text-danger"}`;
                            sessionRefreshStatus.textContent = ok
                                ? dashMessage("refreshed")
                                : dashMessage("refresh_failed");
                        }
                        loadSessionDiagnostics();
                    });
                }

                const diagRefreshBtn = dc.getElementById(
                    "admin-session-diagnostics-refresh"
                );
                if (diagRefreshBtn) {
                    diagRefreshBtn.addEventListener(
                        "click",
                        loadSessionDiagnostics
                    );
                }

                SlideMenus();
                AnchorScrool();

                const editorRoot = dc.getElementById("admin-post-editor");

                const wysiwygEditor = new WysiwygEditor({
                    root: editorRoot,
                    db: DBMethods,
                    permissions: BrowserPermissions,
                    analytics: SiteAnalytics,
                    translate: () => i18n.transcript(),
                    getAuthorId: () =>
                        currentGitHubUser?.id
                            ? String(currentGitHubUser.id)
                            : "",

                    onCreate: async post => {
                        try {
                            const sessionOk =
                                await ensureValidGitHubSession(false);
                            if (!sessionOk || !GitHubAPIInstance) {
                                throw new Error(
                                    "Autenticação do GitHub indisponível."
                                );
                            }

                            if (
                                !post ||
                                !Array.isArray(post.files) ||
                                !post.files.length
                            ) {
                                throw new Error(
                                    "A postagem não contém arquivos para publicação."
                                );
                            }

                            for (const file of post.files) {
                                if (
                                    !file ||
                                    typeof file.path !== "string" ||
                                    !file.path.trim() ||
                                    !("content" in file)
                                ) {
                                    throw new Error(
                                        "A lista de arquivos contém um item inválido."
                                    );
                                }
                            }

                            /**
                             * Sets the repository and branch and pushes the pending files as a single commit.
                             * @return {Promise<void>}
                             */
                            const executeCommit = async () => {
                                const api = GitHubAPIInstance;
                                api.setRepo(REPOSITORY_OWNER, REPOSITORY_NAME);
                                await api.setBranch(REPOSITORY_BRANCH);
                                return api.pushFiles(
                                    `Post: ${post.operation || "create"} "${post.title || post.slug}"`,
                                    post.files
                                );
                            };

                            let response;
                            try {
                                response = await executeCommit();
                            } catch (commitError) {
                                if (commitError?.response?.status === 401) {
                                    const renewed =
                                        await ensureValidGitHubSession(true);
                                    if (!renewed) {
                                        throw new Error(
                                            dashMessage("reauth_needed") ||
                                                "Sessão expirada."
                                        );
                                    }
                                    response = await executeCommit();
                                } else {
                                    throw commitError;
                                }
                            }

                            return { published: true, post, response };
                        } catch (error) {
                            console.error(
                                "[ADMIN]: Falha ao publicar postagem.",
                                error
                            );
                            throw error;
                        }
                    }
                });

                wysiwygEditor.mount();

                const { default: Footoodles } =
                    await import("./modules/models/Footoodles.mjs");

                const footoodles = new Footoodles({
                    getApi: () => GitHubAPIInstance,
                    ensureSession: ensureValidGitHubSession,
                    repo: { owner: REPOSITORY_OWNER, name: REPOSITORY_NAME },
                    branch: REPOSITORY_BRANCH,
                    analytics: SiteAnalytics,
                    translate: path =>
                        path
                            .split(".")
                            .reduce(
                                (node, part) => node?.[part],
                                i18n.dictionary()
                            )
                });

                await footoodles.mount({
                    listEl: dc.getElementById("admin-footoodles-list"),
                    badgeEl: dc.getElementById("admin-footoodles-badge"),
                    emptyEl: dc.getElementById("admin-footoodles-empty"),
                    editorRoot: dc.getElementById("admin-footoodle-editor")
                });
            }
            break;
        }

        case "control":
            break;

        case "donations":
            await TemplatesReady.import;
            setTimeout(AnchorScrool, 500);
            i18n.transcript();
            break;

        case "copyright":
            await TemplatesReady.import;
            setTimeout(AnchorScrool, 500);
            i18n.transcript();
            break;

        case "you-in-control-of-your-data": {
            await TemplatesReady.import;
            const targetHash = location.hash.slice(1);
            if (targetHash === "self-security-hosted") {
                const target = _.DOM.getById("self-security-hosted");
                if (target) {
                    const vertical = target.getBoundingClientRect().y - 120;
                    wd.scrollTo({
                        top: vertical,
                        left: 0,
                        behavior: "smooth"
                    });
                }
            }
            AnchorScrool();
            break;
        }

        case "policy": {
            await TemplatesReady.import;
            (() => {
                let GeneralPolicyBox = _.DOM.getById(
                    "policy-container-general"
                );
                let DataStoragePolicyBox = _.DOM.getById(
                    "policy-container-storage"
                );
                let TermsPolicyBox = _.DOM.getById("policy-container-terms");
                let PrivacyPolicyBox = _.DOM.getById(
                    "policy-container-privacy"
                );

                /**
                 * Opens a print window with the given HTML.
                 * @param {string} _html - Content to print.
                 * @param {string} [_injectHeader=""] - Header to add to the print window.
                 */
                const PrinterJS = (_html, _injectHeader = "") => {
                    let popup = window.open(
                        "about:blank",
                        "PRINT",
                        "rel=noopener"
                    );
                    if (popup) {
                        popup.opener = null;
                        popup.location = location.origin;
                        popup.document.write(`
                            <!DOCTYPE html>
                            <html lang="${document.documentElement.lang || "en-US"}">
                            <head>
                                <title>${document.title}</title>
                                <meta charset="UTF-8">
                                <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                                <link type="text/css" rel="stylesheet" href="/assets/vendor/bootstrapv4/bootstrap.min.css">
                                <link type="text/css" rel="stylesheet" href="/assets/css/main.css">
                                ${_injectHeader}
                            </head>
                            <body class="markdown-body post-content">
                                <h1>${document.title}</h1>
                                ${_html}
                                <script>
                                    document.addEventListener('DOMContentLoaded', function() {
                                        window.print();
                                        window.close();
                                    }, false);
                                <\/script>
                            </body>
                            </html>
                        `);
                        popup.document.close();
                        popup.focus();
                    }
                    return true;
                };

                if (
                    GeneralPolicyBox &&
                    !DataStoragePolicyBox &&
                    TermsPolicyBox &&
                    PrivacyPolicyBox
                ) {
                    const PolicyHeaders = [
                        `<h2>${i18n.getWord("pages.policy.privacy.heading")}</h2>`,
                        `<h2>${i18n.getWord("pages.policy.terms.heading")}</h2>`,
                        `<h2>${i18n.getWord("pages.policy.general.heading")}</h2>`
                    ];
                    const boxes = [
                        PrivacyPolicyBox,
                        TermsPolicyBox,
                        GeneralPolicyBox
                    ];
                    const AllPolicyContentHTML = boxes
                        .map((elm, idx) => PolicyHeaders[idx] + elm.innerHTML)
                        .join("");

                    if (
                        !GeneralPolicyBox.querySelector(".printable-launcher")
                    ) {
                        const generalText = GeneralPolicyBox.textContent || "";
                        GeneralPolicyBox.insertAdjacentHTML(
                            "afterbegin",
                            `
                            <div class="col-12 my-2 px-0">
                                <span class="badge badge-light border-def contrast" title="${i18n.getWord("pages.policy.badges.reading_title")}">${i18n.getWord("blog.read_time").replace("{minutes}", ReadingTextTime(generalText).time)}</span>
                                <span class="badge badge-dark" title="${i18n.getWord("pages.policy.badges.version_title")}">${i18n.getWord("pages.policy.badges.version").replace("{version}", "1.0.0")}</span>
                                <span class="badge badge-light border-def contrast mt-1 cp printable-launcher" title="${i18n.getWord("pages.policy.badges.print_title")}">${i18n.getWord("pages.policy.badges.print")}</span>
                            </div>`
                        );
                    }

                    const printBtn = GeneralPolicyBox.querySelector(
                        ".printable-launcher"
                    );
                    if (printBtn) {
                        printBtn.addEventListener(
                            "click",
                            () => {
                                PrinterJS(AllPolicyContentHTML);
                            },
                            false
                        );
                    }

                    const targetHash = location.hash.slice(1);
                    if (
                        location.hash !== "" &&
                        [
                            "policy-general",
                            "policy-terms",
                            "policy-privacy",
                            "cookie-agree"
                        ].includes(targetHash)
                    ) {
                        let target = null;
                        switch (targetHash) {
                            case "policy-privacy":
                                target = _.DOM.getById(
                                    "policy-container-privacy"
                                );
                                break;
                            case "policy-terms":
                                target = _.DOM.getById(
                                    "policy-container-terms"
                                );
                                break;
                            case "policy-general":
                                target = _.DOM.getById(
                                    "policy-container-general"
                                );
                                break;
                            case "cookie-agree":
                                target = _.DOM.getById("policy-cookie-agree");
                                break;
                        }
                        if (target) {
                            let vertical =
                                target.getBoundingClientRect().y - 120;
                            wd.scrollTo({
                                top: vertical,
                                left: 0,
                                behavior: "smooth"
                            });
                        }
                    }

                    AnchorScrool();
                } else {
                    console.error("[POLICY]: policy containers not found");
                }
            })();

            let AcceptCookiesBtn = _.DOM.getById("yes-cookies-accept");

            if (AcceptCookiesBtn) {
                /**
                 * Changes the cookie button so it opens the disable-cookies modal.
                 */
                const GoToDisable = () => {
                    AcceptCookiesBtn.innerHTML =
                        i18n.dictionary().pages.policy.cookies.disable;
                    AcceptCookiesBtn.setAttribute("data-toggle", "modal");
                    AcceptCookiesBtn.setAttribute(
                        "data-target",
                        "#modal-clear-metadata"
                    );
                    // re-launch Bootstrap Native for this dinamic attributes
                    //BootstrapNative.initCallback(AcceptCookiesBtn.parentElement)
                    _.DOM.waitEl(dc, "#modal-clear-metadata", list => {
                        list[0]
                            ? BootstrapNative.initCallback(
                                  AcceptCookiesBtn.parentElement
                              )
                            : null;
                    });

                    /**
                     * Removes the modal attributes from the cookie button.
                     */
                    const RemoveAttr = () => {
                        AcceptCookiesBtn.removeAttribute("data-toggle");
                        AcceptCookiesBtn.removeAttribute("data-target");
                    };

                    // check cookies
                    [...dc.querySelectorAll("[data-charge-type]")].forEach(
                        btn => {
                            let finish;

                            PressHoldCollorCharger(
                                btn,
                                init => {
                                    btn.classList.add(btn.dataset.chargeType);
                                },
                                end => {
                                    btn.classList.remove(
                                        btn.dataset.chargeType
                                    );
                                    if (finish) {
                                        if (
                                            btn.id === "clear-all-data-storage"
                                        ) {
                                            Policy.refuseStoragement(
                                                true /*force clear-all-data but, not cookie*/
                                            )
                                                .then(success => {
                                                    RemoveAttr();
                                                    wd.location.reload(true);
                                                    // notify
                                                })
                                                .catch(error => {
                                                    console.error(
                                                        "[POLICY]: could not clear the data storage",
                                                        error
                                                    );
                                                    // notify
                                                });
                                        } else if (
                                            btn.id === "refuse-cookie-storage"
                                        ) {
                                            Policy.refuseStoragement()
                                                .then(success => {
                                                    RemoveAttr();
                                                    wd.location.reload(true);
                                                    // notify
                                                })
                                                .catch(error => {
                                                    console.error(
                                                        "[POLICY]: could not disable cookies",
                                                        error
                                                    );
                                                    // notify
                                                });
                                        }
                                        //finish = false
                                    }
                                },
                                complete => {
                                    finish = true;
                                },
                                100
                            );
                        }
                    );
                };
                // check cookie state
                if (Policy.permission === "authorized") {
                    GoToDisable();
                } else {
                    PressHoldCollorCharger(
                        AcceptCookiesBtn,
                        init => {
                            AcceptCookiesBtn.classList.add(
                                "background-charge-success"
                            );
                        },
                        end => {
                            AcceptCookiesBtn.classList.remove(
                                "background-charge-success"
                            );
                        },
                        complete => {
                            Policy.acceptStoragement()
                                .then(success => {
                                    AcceptCookiesBtn.classList.remove(
                                        "background-charge-success"
                                    );
                                    GoToDisable();
                                    // notify
                                })
                                .catch(error => {
                                    console.error(
                                        "[POLICY]: could not enable cookies",
                                        error
                                    );
                                    // notify
                                });
                        },
                        100
                    );
                }
            }

            break;
        }

        default:
            break;
    }
    renderFooterNews(
        settings,
        document.getElementById("dinamic-footer-news"),
        PolicyHandler.language,
        { analytics: SiteAnalytics }
    );

    // @revise - lazy-load global initializator?
    // @oriority: MEDIUM
    lazyLoad.observe([...dc.querySelectorAll("[data-lazy-target]")]);

    // storage policy info
    router !== "policy" && router !== "nocookie" ? DataStoragePolicy() : null;

    // @revise - random RBG ... for `footer#foothead` (change this to UIModel.mjs)
    // @priority: LESS
    let bgColor = `rgb(${[1, 2, 3].map(x => (Math.random() * 256) | 0)})`;
    try {
        // Sets the custom property on the root element, independent of stylesheet order.
        dc.documentElement.style.setProperty("--random-color", bgColor);

        let element = document.getElementById("foothead");

        // If the background color is dark, add the light-text class to it
        if (!BrightnessDetector(bgColor)) {
            element.classList.add("light-text");
        } else {
            element.classList.add("dark-text");
        }
    } catch (e) {
        /*console.log(e)*/
    }

    // fix BootstrapNative Modals for dinamic templates
    /**
     * Prevents the default action of the elements marked with data-fix-modal inside the given root.
     * @param {Document|HTMLElement} [root=dc]
     */
    const processFixModals = (root = dc) => {
        root.querySelectorAll("[data-fix-modal]").forEach(element => {
            if (element.tagName === "A") {
                _.DOM.event(
                    element,
                    "click",
                    evt => {
                        evt.preventDefault();
                    },
                    _.EventOptions(false, false, false)
                );
            }
            let attribute = element.dataset.fixModal;
            element.removeAttribute("data-fix-modal");
            element.setAttribute("data-toggle", "modal");
            element.setAttribute("data-target", attribute);
            _.DOM.waitEl(dc, attribute, list => {
                list[0]
                    ? BootstrapNative.initCallback(element.parentElement)
                    : null;
            });
        });
    };

    processFixModals();

    _.DOM.event(dc, "click", evt => {
        const link =
            evt.target && evt.target.closest
                ? evt.target.closest('a[href="::"], [data-fix-modal]')
                : null;
        if (link) {
            evt.preventDefault();
            if (link.dataset.fixModal) {
                processFixModals(dc);
            }
        }
    });

    // @revise - anchor smooth (revise Functions.mjs and add dinamic elements observer filter)
    // @priority: MEDIUM
    AnchorScrool();

    i18n.transcript();
    i18n.observe(document);

    dc.documentElement.classList.remove("i18n-loading");
    const preferenceSwitches = {
        "sets-media-audio": "mediaAudio",
        "sets-media-video": "mediaVideo",
        "sets-geo-stats": "geoStats",
        "sets-effect-audio": "effectAudio",
        "sets-effect-notific": "effectNotific",
        "sets-conn-notific": "connNotific",
        "sets-conn-notific2": "connNotific2"
    };

    const userPreferences = {
        mediaAudio: false,
        mediaVideo: false,
        geoStats: false,
        effectAudio: false,
        effectNotific: false,
        connNotific: false,
        connNotific2: false
    };

    if (DBMethods) {
        try {
            const savedPreferences = await DBMethods.read({
                tbn: "config",
                tbk: "preferences"
            });

            if (
                savedPreferences &&
                typeof savedPreferences === "object" &&
                !Array.isArray(savedPreferences)
            ) {
                Object.keys(userPreferences).forEach(key => {
                    if (typeof savedPreferences[key] === "boolean") {
                        userPreferences[key] = savedPreferences[key];
                    }
                });
            }
        } catch (error) {
            console.error("[SETUP]: Could not load user preferences", error);
            SiteAnalytics?.trackError("preferences", error).catch(() => {});
        }

        userPreferences.connNotific2 = Boolean(Policy.analyticsEnabled);
    }

    /**
     * Shows the state of a preference with a coloured indicator.
     * @param {string} id - Element identifier.
     * @param {boolean} enabled
     */
    const renderPreferenceSwitch = (id, enabled) => {
        const element = dc.getElementById(id);
        if (!element) return;

        const indicator = element.querySelector(".preference-indicator");
        if (!indicator) return;

        indicator.textContent = enabled ? "🟢" : "🔴";
    };

    Object.entries(preferenceSwitches).forEach(([id, key]) => {
        renderPreferenceSwitch(id, userPreferences[key]);
    });

    let preferenceSaveQueue = Promise.resolve();

    dc.addEventListener("click", evt => {
        const element = evt.target.closest(
            "#settings-slide .preference-switch"
        );

        if (
            !element ||
            !Object.prototype.hasOwnProperty.call(
                preferenceSwitches,
                element.id
            )
        ) {
            return;
        }

        const key = preferenceSwitches[element.id];

        userPreferences[key] = !userPreferences[key];

        renderPreferenceSwitch(element.id, userPreferences[key]);

        if (!DBMethods) {
            console.error(
                "[SETUP]: IndexedDB connection unavailable; preference not saved."
            );
            return;
        }

        const preferencesToSave = { ...userPreferences };

        preferenceSaveQueue = preferenceSaveQueue
            .then(async () => {
                await DBMethods.update([
                    {
                        tbn: "config",
                        tbk: "preferences",
                        tbv: preferencesToSave
                    }
                ]);

                if (key === "connNotific2") {
                    await Policy.setAnalyticsConsent(
                        preferencesToSave.connNotific2,
                        DBMethods
                    );
                    await SiteAnalytics?.setEnabled(
                        preferencesToSave.connNotific2
                    );
                }
            })
            .catch(error => {
                console.error(
                    "[SETUP]: Could not save user preferences",
                    error
                );
            });
    });

    DrawerEvents(BrowserPermissions, Notify);

    SlideMenus();

    ColorPallet("#color-palette-container");

    //}, _.EventOptions(false, true, true), true);
};

if (dc.readyState === "loading") {
    _.DOM.event(dc, "DOMContentLoaded", SetupDOMReady);
} else {
    SetupDOMReady();
}

// Drawer > clear modal: press and hold the button to erase all browser data.
// Independent from the cookie consent buttons on the policy page.
/**
 * Binds the press-and-hold button that clears all data.
 * @param {HTMLElement} button
 * @description The binding runs only once per button.
 */
const bindClearAllButton = button => {
    if (button.dataset.clearBound) return;
    button.dataset.clearBound = "true";

    let completed = false;

    PressHoldCollorCharger(
        button,
        () => {
            button.classList.add("background-charge-danger");
        },
        () => {
            button.classList.remove("background-charge-danger");
            if (!completed) return;
            completed = false;
            Policy.refuseStoragement(true)
                .then(() => wd.location.reload())
                .catch(error =>
                    console.error("[SETUP]: clear all data failed", error)
                );
        },
        () => {
            completed = true;
        },
        100
    );
};

const clearAllButton = dc.getElementById("clear-all-data-storage");
if (clearAllButton) bindClearAllButton(clearAllButton);

// The modals are injected by templates: bind the button as soon as it exists.
new MutationObserver(() => {
    const button = dc.getElementById("clear-all-data-storage");
    if (button) bindClearAllButton(button);
}).observe(dc.body, { childList: true, subtree: true });

// Footoodles: inject one random item into the footer head on any page.
// Uses the settings already loaded by setup; no admin module is imported.
/**
 * Shows a random footoodle in the footer.
 * @description Does nothing when there are no footoodles in the settings.
 */
const injectFootoodle = () => {
    const list = settings.articles?.footoodles ?? [];
    if (!list.length) return;

    const item = list[Math.floor(Math.random() * list.length)];

    const title = document.getElementById("footer-fh-title");
    const content = document.getElementById("footer-fh-content");
    const image = document.getElementById("footer-fh-img");

    if (title) title.textContent = item.title;
    if (content) content.textContent = item.content;
    if (image)
        image.style.backgroundImage = `url("/${String(item.image || "").replace(/^\/+/, "")}")`;

    // Shows the section only when there is something to show.
    document.getElementById("foothead")?.classList.remove("d-none");
};

injectFootoodle();

// Share: uses the native share sheet when available, otherwise copies the link.
dc.addEventListener("click", async event => {
    if (!event.target.closest("#drawer-share")) return;

    const data = { title: document.title, url: location.href };

    try {
        if (navigator.share) {
            await navigator.share(data);
        } else {
            await navigator.clipboard?.writeText(location.href);
        }
    } catch (error) {
        // the user cancelled the share sheet
    }
});
/**
 * Clears the GitHub credentials after confirmation, ending the session and reloading the panel.
 *
 * @param {Event} event - Click event on a clear-credentials button.
 * @return {Promise<void>}
 * @description Calls the logout endpoint, removes the stored user-github record from IndexedDB and reloads the page. If the operation fails, the button is enabled again.
 */
const handleGitHubCredentialsClear = async event => {
    const button = event.target.closest(
        "#admin-github-credentials-clear, " + "#admin-session-credentials-clear"
    );

    if (!button) return;

    const confirmText =
        dc
            .querySelector(
                '#admin-dashboard-messages [data-msg="clear_confirm"]'
            )
            ?.textContent?.trim() || "Clear GitHub credentials?";

    if (!wd.confirm(confirmText)) return;

    if (!DBMethods) {
        console.error(
            "[ADMIN]: IndexedDB indisponível; não foi possível limpar as credenciais."
        );
        return;
    }

    button.disabled = true;

    try {
        await fetch("/admin-auth/logout", {
            method: "POST",
            credentials: "same-origin"
        }).catch(() => null);

        await DBMethods.delete({
            tbn: "github",
            tbk: "user-github"
        });

        wd.location.reload();
    } catch (error) {
        button.disabled = false;

        console.error(
            "[ADMIN]: Não foi possível limpar as credenciais do GitHub.",
            error
        );
    }
};

dc.addEventListener("click", handleGitHubCredentialsClear);
